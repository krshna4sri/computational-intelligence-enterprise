"""
Multi-Objective Simulated Annealing for Supply Chain Management
===============================================================

A working POC that uses Simulated Annealing (SA) to jointly minimize
**transportation cost** and **CO2 emissions** across a multi-lane
transportation network — a classic multi-objective SCM problem.

Two multi-objective strategies are implemented side-by-side:

1. **Weighted-sum scalarization** — simplest, tuneable via `w_cost`, `w_co2`.
2. **Pareto archive SA (Archive MOSA)** — maintains an external archive of
   non-dominated solutions and uses a dominance-based acceptance rule.

Solution encoding
-----------------
A solution is a 2-D integer matrix `x[i, j]` giving the chosen transport mode
(0 = truck, 1 = rail, 2 = air) for every lane (origin i, destination j).
Lanes with zero demand are ignored.

Run it
------
    python -m poc.simulated_annealing.mosa_scm
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from poc.common import (
    RunReport,
    make_transportation_network,
    save_convergence_plot,
    set_seed,
    stopwatch,
)


# ---------------------------------------------------------------------------
# Problem
# ---------------------------------------------------------------------------

@dataclass
class TransportProblem:
    data: dict

    @property
    def shape(self) -> Tuple[int, int]:
        return self.data["distance_km"].shape

    @property
    def n_modes(self) -> int:
        return int(self.data["mode_cost_per_km_per_unit"].shape[0])

    def random_solution(self, rng: np.random.Generator) -> np.ndarray:
        return rng.integers(0, self.n_modes, size=self.shape).astype(np.int8)

    def evaluate(self, x: np.ndarray) -> Tuple[float, float]:
        """Return (total_cost, total_emissions_kg)."""
        dist = self.data["distance_km"]
        demand = self.data["demand_units"]
        mode_cost = self.data["mode_cost_per_km_per_unit"]
        mode_em = self.data["mode_emissions_per_km_per_unit"]

        cost_per_unit = mode_cost[x] * dist          # elementwise
        em_per_unit = mode_em[x] * dist

        total_cost = float((cost_per_unit * demand).sum())
        total_em = float((em_per_unit * demand).sum())
        return total_cost, total_em


# ---------------------------------------------------------------------------
# Shared neighbour operator
# ---------------------------------------------------------------------------

def _perturb(
    x: np.ndarray, problem: TransportProblem, rng: np.random.Generator, k: int = 1
) -> np.ndarray:
    """Flip the mode of `k` randomly-chosen lanes."""
    n_rows, n_cols = problem.shape
    new = x.copy()
    for _ in range(k):
        i = int(rng.integers(0, n_rows))
        j = int(rng.integers(0, n_cols))
        current = int(new[i, j])
        choices = [m for m in range(problem.n_modes) if m != current]
        new[i, j] = int(rng.choice(choices))
    return new


# ---------------------------------------------------------------------------
# Variant 1: Weighted-sum SA
# ---------------------------------------------------------------------------

@dataclass
class SAConfig:
    initial_temperature: float = 1000.0
    cooling_rate: float = 0.97
    iterations: int = 3000
    neighbors_per_temp: int = 1
    w_cost: float = 0.6
    w_co2: float = 0.4


def run_weighted_sum_sa(
    problem: TransportProblem, config: SAConfig = SAConfig(), seed: int = 0
) -> RunReport:
    rng = np.random.default_rng(seed)
    x = problem.random_solution(rng)
    cost, em = problem.evaluate(x)
    f = config.w_cost * cost + config.w_co2 * em

    best = x.copy()
    best_f = f
    best_cost, best_em = cost, em

    T = config.initial_temperature
    trace = [best_f]

    with stopwatch() as elapsed:
        for it in range(config.iterations):
            for _ in range(config.neighbors_per_temp):
                y = _perturb(x, problem, rng)
                yc, ye = problem.evaluate(y)
                yf = config.w_cost * yc + config.w_co2 * ye
                delta = yf - f
                if delta < 0 or rng.random() < math.exp(-delta / max(T, 1e-9)):
                    x, f, cost, em = y, yf, yc, ye
                    if f < best_f:
                        best, best_f = x.copy(), f
                        best_cost, best_em = cost, em
            T *= config.cooling_rate
            trace.append(best_f)
        total_time = elapsed()

    return RunReport(
        algorithm="SA (weighted sum)",
        problem="multi_obj_transport",
        best_fitness=best_f,
        best_solution=best.astype(int).tolist(),
        iterations=config.iterations,
        wall_time_seconds=total_time,
        convergence_trace=trace,
        extra={"best_cost": best_cost, "best_co2_kg": best_em,
               "weights": {"cost": config.w_cost, "co2": config.w_co2}},
    )


# ---------------------------------------------------------------------------
# Variant 2: Pareto archive SA (MOSA)
# ---------------------------------------------------------------------------

def _dominates(a: Tuple[float, float], b: Tuple[float, float]) -> bool:
    return (a[0] <= b[0] and a[1] <= b[1]) and (a[0] < b[0] or a[1] < b[1])


def _update_archive(
    archive: List[Tuple[np.ndarray, float, float]],
    cand: np.ndarray,
    cand_obj: Tuple[float, float],
    max_size: int = 50,
) -> List[Tuple[np.ndarray, float, float]]:
    """Insert `cand` into archive, remove dominated entries, trim if needed."""
    # Drop dominated
    kept = [(x, c, e) for (x, c, e) in archive if not _dominates(cand_obj, (c, e))]
    # If cand is dominated by any kept entry, skip it
    if any(_dominates((c, e), cand_obj) for (_, c, e) in kept):
        return kept
    # Avoid exact duplicates
    for (_, c, e) in kept:
        if math.isclose(c, cand_obj[0]) and math.isclose(e, cand_obj[1]):
            return kept
    kept.append((cand.copy(), cand_obj[0], cand_obj[1]))
    # Trim by crowding (keep diverse front)
    if len(kept) > max_size:
        kept.sort(key=lambda t: (t[1], t[2]))
        # Drop every other element
        kept = kept[::2]
    return kept


def run_weight_sweep_mosa(
    problem: TransportProblem,
    config: SAConfig = SAConfig(),
    seed: int = 0,
    n_weights: int = 11,
) -> RunReport:
    """Produce a Pareto front by running weighted-sum SA at many weight values.

    This is the most robust way to get a well-spread front for a two-objective
    problem. For each alpha in [0, 1], we run SA minimizing
    alpha*cost + (1-alpha)*emissions, then merge all results and keep the
    non-dominated set.
    """
    rng = np.random.default_rng(seed)
    front: List[Tuple[np.ndarray, float, float]] = []

    trace: List[float] = []
    with stopwatch() as elapsed:
        for k, alpha in enumerate(np.linspace(0.0, 1.0, n_weights)):
            local_cfg = SAConfig(
                initial_temperature=config.initial_temperature,
                cooling_rate=config.cooling_rate,
                iterations=config.iterations,
                w_cost=float(alpha),
                w_co2=float(1.0 - alpha),
            )
            r = run_weighted_sum_sa(problem, local_cfg, seed=seed + 17 * k)
            c = r.extra["best_cost"]
            e = r.extra["best_co2_kg"]
            sol = np.array(r.best_solution, dtype=np.int8)
            front = _update_archive(front, sol, (c, e), max_size=200)
            trace.append(min(cc + ee for (_, cc, ee) in front))
        total_time = elapsed()

    knee = min(front, key=lambda t: t[1] + t[2])
    return RunReport(
        algorithm="MOSA (weight sweep)",
        problem="multi_obj_transport",
        best_fitness=knee[1] + knee[2],
        best_solution=knee[0].astype(int).tolist(),
        iterations=n_weights,
        wall_time_seconds=total_time,
        convergence_trace=trace,
        extra={
            "pareto_front_size": len(front),
            "pareto_front": [
                {"cost": c, "co2_kg": e}
                for (_, c, e) in sorted(front, key=lambda t: t[1])
            ],
            "knee_cost": knee[1],
            "knee_co2_kg": knee[2],
        },
    )


def run_archive_mosa(
    problem: TransportProblem,
    config: SAConfig = SAConfig(),
    seed: int = 0,
    archive_size: int = 40,
) -> RunReport:
    rng = np.random.default_rng(seed)
    x = problem.random_solution(rng)
    cost, em = problem.evaluate(x)

    archive: List[Tuple[np.ndarray, float, float]] = [(x.copy(), cost, em)]
    T = config.initial_temperature
    trace: List[float] = [cost + em]

    with stopwatch() as elapsed:
        for it in range(config.iterations):
            y = _perturb(x, problem, rng)
            yc, ye = problem.evaluate(y)
            cur_obj, new_obj = (cost, em), (yc, ye)

            if _dominates(new_obj, cur_obj):
                accept = True
            elif _dominates(cur_obj, new_obj):
                # Worse in Pareto sense -> probabilistic
                delta = (yc - cost) + (ye - em)
                accept = rng.random() < math.exp(-max(delta, 0) / max(T, 1e-9))
            else:
                # Neither dominates -> accept with prob 0.5
                accept = rng.random() < 0.5

            if accept:
                x, cost, em = y, yc, ye

            archive = _update_archive(archive, x, (cost, em), max_size=archive_size)
            T *= config.cooling_rate
            # Track archive "knee" = min( cost + em )
            trace.append(min(c + e for (_, c, e) in archive))
        total_time = elapsed()

    # Report the knee solution (balanced)
    knee = min(archive, key=lambda t: t[1] + t[2])
    return RunReport(
        algorithm="MOSA (Pareto archive)",
        problem="multi_obj_transport",
        best_fitness=knee[1] + knee[2],
        best_solution=knee[0].astype(int).tolist(),
        iterations=config.iterations,
        wall_time_seconds=total_time,
        convergence_trace=trace,
        extra={
            "pareto_front_size": len(archive),
            "pareto_front": [
                {"cost": c, "co2_kg": e} for (_, c, e) in sorted(archive, key=lambda t: t[1])
            ],
            "knee_cost": knee[1],
            "knee_co2_kg": knee[2],
        },
    )


# ---------------------------------------------------------------------------
# Demo entry point
# ---------------------------------------------------------------------------

def main() -> None:
    set_seed(0)
    data = make_transportation_network(n_locations=6, seed=7)
    problem = TransportProblem(data=data)

    cfg = SAConfig(initial_temperature=2000, cooling_rate=0.985, iterations=800)

    print("=== Weighted-sum SA ===")
    r1 = run_weighted_sum_sa(problem, cfg, seed=1)
    print(r1.summary())
    print(f"  cost=${r1.extra['best_cost']:.2f}  CO2={r1.extra['best_co2_kg']:.2f} kg")

    print("\n=== Archive MOSA ===")
    r2 = run_archive_mosa(problem, cfg, seed=1)
    print(r2.summary())
    print(f"  Pareto front points: {r2.extra['pareto_front_size']}")
    print(f"  Knee solution cost=${r2.extra['knee_cost']:.2f}  "
          f"CO2={r2.extra['knee_co2_kg']:.2f} kg")

    save_convergence_plot(
        r1.convergence_trace, "/tmp/sa_weighted_convergence.png",
        "Weighted-Sum SA — Best Scalarized Objective",
    )
    save_convergence_plot(
        r2.convergence_trace, "/tmp/mosa_convergence.png",
        "Archive MOSA — Pareto 'Knee' Objective",
    )


if __name__ == "__main__":
    main()

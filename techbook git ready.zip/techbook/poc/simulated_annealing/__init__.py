"""Simulated Annealing for multi-objective SCM optimization."""

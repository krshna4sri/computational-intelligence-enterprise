"""
Hybrid Particle Swarm Optimization + Genetic Algorithm (HPSO-GA)
================================================================

A working POC of the hybrid algorithm combining PSO's local refinement with
GA's global exploration, applied to multi-product inventory optimization.

Hybridization strategy (from the preprint)
------------------------------------------
Each iteration runs **both** a PSO step and a GA step:
  1. PSO velocity/position update on the swarm.
  2. GA step (selection, crossover, mutation) on a parallel population
     that borrows fitness information from the swarm's personal bests.
  3. Cross-pollination: any GA child that improves on a particle's personal
     best replaces that particle's position.

The rationale: PSO alone often stalls in a local basin; GA alone converges
slowly on continuous problems. Running them on the same shared fitness and
swapping promising solutions keeps exploration alive and speeds exploitation.

Run it
------
    python -m poc.hybrid_pso_ga.hybrid
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np

from poc.common import (
    RunReport,
    make_inventory_dataset,
    save_convergence_plot,
    set_seed,
    stopwatch,
)
from poc.pso.pso_inventory import InventoryProblem, PSOConfig


# ---------------------------------------------------------------------------
# Hybrid config
# ---------------------------------------------------------------------------

@dataclass
class HybridConfig(PSOConfig):
    crossover_rate: float = 0.7
    mutation_rate: float = 0.1
    mutation_sigma_frac: float = 0.08   # Gaussian mutation std, fraction of range
    ga_tournament_k: int = 3


# ---------------------------------------------------------------------------
# GA operators (continuous)
# ---------------------------------------------------------------------------

def _tournament(
    pop: np.ndarray, fitness: np.ndarray, k: int, rng: np.random.Generator
) -> np.ndarray:
    idx = rng.integers(0, len(pop), size=k)
    return pop[idx[int(np.argmin(fitness[idx]))]].copy()


def _blx_alpha_crossover(
    a: np.ndarray, b: np.ndarray, rng: np.random.Generator, alpha: float = 0.5
) -> np.ndarray:
    """BLX-α crossover: child drawn from interval extended by α on each side."""
    lo = np.minimum(a, b)
    hi = np.maximum(a, b)
    d = hi - lo
    low = lo - alpha * d
    high = hi + alpha * d
    return rng.uniform(low, high)


def _gaussian_mutate(
    x: np.ndarray, sigma: np.ndarray, rate: float, rng: np.random.Generator
) -> np.ndarray:
    mask = rng.random(size=x.shape) < rate
    noise = rng.normal(0.0, sigma, size=x.shape)
    return x + mask * noise


# ---------------------------------------------------------------------------
# Hybrid runner
# ---------------------------------------------------------------------------

def run_hybrid_pso_ga(
    problem: InventoryProblem, config: HybridConfig = HybridConfig(), seed: int = 0
) -> RunReport:
    rng = np.random.default_rng(seed)
    n = config.n_particles
    d = problem.n_products

    # Initialize PSO side
    x = rng.uniform(config.lower, config.upper, size=(n, d))
    v_max = config.v_max_frac * (config.upper - config.lower)
    v = rng.uniform(-v_max, v_max, size=(n, d))
    pbest = x.copy()
    pbest_f = np.array([problem.fitness(xi) for xi in x])
    g_idx = int(np.argmin(pbest_f))
    gbest = pbest[g_idx].copy()
    gbest_f = float(pbest_f[g_idx])

    # GA side starts from same initial population but evolves independently
    ga_pop = x.copy()
    ga_fit = pbest_f.copy()

    sigma = config.mutation_sigma_frac * (config.upper - config.lower) * np.ones(d)
    trace: List[float] = [gbest_f]

    with stopwatch() as elapsed:
        for it in range(config.iterations):
            # ---------- PSO step ------------------------------------------
            w = config.w_start + (config.w_end - config.w_start) * (it / max(1, config.iterations - 1))
            r1 = rng.random(size=(n, d))
            r2 = rng.random(size=(n, d))
            v = (
                w * v
                + config.c1 * r1 * (pbest - x)
                + config.c2 * r2 * (gbest - x)
            )
            np.clip(v, -v_max, v_max, out=v)
            x = np.clip(x + v, config.lower, config.upper)
            f = np.array([problem.fitness(xi) for xi in x])

            improved = f < pbest_f
            pbest[improved] = x[improved]
            pbest_f[improved] = f[improved]
            g_idx = int(np.argmin(pbest_f))
            if pbest_f[g_idx] < gbest_f:
                gbest = pbest[g_idx].copy()
                gbest_f = float(pbest_f[g_idx])

            # ---------- GA step -------------------------------------------
            new_ga = np.empty_like(ga_pop)
            for i in range(n):
                p1 = _tournament(ga_pop, ga_fit, config.ga_tournament_k, rng)
                p2 = _tournament(ga_pop, ga_fit, config.ga_tournament_k, rng)
                if rng.random() < config.crossover_rate:
                    child = _blx_alpha_crossover(p1, p2, rng)
                else:
                    child = p1
                child = _gaussian_mutate(child, sigma, config.mutation_rate, rng)
                new_ga[i] = np.clip(child, config.lower, config.upper)
            ga_pop = new_ga
            ga_fit = np.array([problem.fitness(xi) for xi in ga_pop])

            # ---------- Cross-pollination --------------------------------
            # If a GA child beats the corresponding particle's personal best,
            # replace the swarm slot entirely.
            cross_mask = ga_fit < pbest_f
            if cross_mask.any():
                pbest[cross_mask] = ga_pop[cross_mask]
                pbest_f[cross_mask] = ga_fit[cross_mask]
                x[cross_mask] = ga_pop[cross_mask]
                v[cross_mask] *= 0.5  # reset momentum for inherited slots

                g_idx = int(np.argmin(pbest_f))
                if pbest_f[g_idx] < gbest_f:
                    gbest = pbest[g_idx].copy()
                    gbest_f = float(pbest_f[g_idx])

            trace.append(gbest_f)
        total_time = elapsed()

    return RunReport(
        algorithm="Hybrid PSO-GA",
        problem="inventory_management",
        best_fitness=gbest_f,
        best_solution=gbest.tolist(),
        iterations=config.iterations,
        wall_time_seconds=total_time,
        convergence_trace=trace,
        extra={
            "order_quantities": gbest.tolist(),
            "demand": problem.data["historical_demand"].tolist(),
        },
    )


# ---------------------------------------------------------------------------
# Demo entry point: compare PSO vs Hybrid PSO-GA head-to-head
# ---------------------------------------------------------------------------

def main() -> None:
    from poc.pso.pso_inventory import run_pso

    set_seed(123)
    data = make_inventory_dataset(n_products=8, seed=42)
    problem = InventoryProblem(data=data)

    cfg = HybridConfig(n_particles=30, iterations=250)

    r_pso = run_pso(problem, PSOConfig(n_particles=30, iterations=250), seed=1)
    r_hy = run_hybrid_pso_ga(problem, cfg, seed=1)

    print("=== PSO baseline ===")
    print(r_pso.summary())
    print("=== Hybrid PSO-GA ===")
    print(r_hy.summary())
    print(f"\nImprovement of Hybrid over PSO: "
          f"{100 * (r_pso.best_fitness - r_hy.best_fitness) / r_pso.best_fitness:.2f}%")

    save_convergence_plot(
        r_hy.convergence_trace,
        "/tmp/hybrid_psoga_convergence.png",
        "Hybrid PSO-GA — Inventory Total-Cost Convergence",
    )


if __name__ == "__main__":
    main()

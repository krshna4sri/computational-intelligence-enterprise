"""Hybrid Particle Swarm Optimization + Genetic Algorithm."""

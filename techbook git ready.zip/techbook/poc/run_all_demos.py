"""
Unified POC runner — exercises every algorithm in the book and prints a
side-by-side comparison table.

Run it from the techbook/ directory:

    python -m poc.run_all_demos
"""

from __future__ import annotations

from poc.agoa.agoa_scm import (
    AGOAConfig,
    SupplyNetworkProblem,
    run_agoa,
)
from poc.bessel_bfd.bfd_classifier import BFDConfig, run_bfd_pipeline
from poc.common import (
    make_inventory_dataset,
    make_supply_network,
    make_transportation_network,
    set_seed,
)
from poc.hybrid_pso_ga.hybrid import HybridConfig, run_hybrid_pso_ga
from poc.pso.pso_inventory import InventoryProblem, PSOConfig, run_pso
from poc.simulated_annealing.mosa_scm import (
    SAConfig,
    TransportProblem,
    run_archive_mosa,
    run_weighted_sum_sa,
)


def main() -> None:
    set_seed(42)

    print("=" * 78)
    print(" RUNNING ALL POCs")
    print("=" * 78)

    # ---- AGOA ---------------------------------------------------------
    print("\n[1/5] AGOA — Adaptive Genetic Optimization")
    print("-" * 78)
    agoa_data = make_supply_network(n_suppliers=5, n_plants=3, n_dcs=6, seed=11)
    agoa_problem = SupplyNetworkProblem(data=agoa_data)
    agoa_report = run_agoa(
        agoa_problem, AGOAConfig(population_size=60, generations=120), seed=1
    )
    print(agoa_report.summary())
    print(f"  Supplier->Plant : {agoa_report.best_solution['supplier_to_plant']}")
    print(f"  Plant   ->DC    : {agoa_report.best_solution['plant_to_dc']}")

    # ---- SA (weighted + archive) --------------------------------------
    print("\n[2/5] Simulated Annealing — Multi-Objective Transport")
    print("-" * 78)
    sa_data = make_transportation_network(n_locations=6, seed=7)
    sa_problem = TransportProblem(data=sa_data)
    sa_cfg = SAConfig(initial_temperature=2000, cooling_rate=0.985, iterations=500)
    sa_w = run_weighted_sum_sa(sa_problem, sa_cfg, seed=1)
    sa_a = run_archive_mosa(sa_problem, sa_cfg, seed=1)
    print("  ", sa_w.summary())
    print(f"     cost=${sa_w.extra['best_cost']:.2f}  CO2={sa_w.extra['best_co2_kg']:.2f}kg")
    print("  ", sa_a.summary())
    print(f"     pareto_front_size={sa_a.extra['pareto_front_size']}  "
          f"knee_cost=${sa_a.extra['knee_cost']:.2f}  knee_CO2={sa_a.extra['knee_co2_kg']:.2f}kg")

    # ---- PSO ----------------------------------------------------------
    print("\n[3/5] Particle Swarm Optimization — Inventory")
    print("-" * 78)
    inv_data = make_inventory_dataset(n_products=6, seed=42)
    inv_problem = InventoryProblem(data=inv_data)
    pso_report = run_pso(inv_problem, PSOConfig(n_particles=30, iterations=200), seed=1)
    print(pso_report.summary())
    print(f"  Demand : {[round(x, 1) for x in inv_data['historical_demand'].tolist()]}")
    print(f"  Q (PSO): {[round(x, 1) for x in pso_report.best_solution]}")

    # ---- Hybrid PSO-GA -----------------------------------------------
    print("\n[4/5] Hybrid PSO-GA — Inventory")
    print("-" * 78)
    hy_report = run_hybrid_pso_ga(
        inv_problem, HybridConfig(n_particles=30, iterations=200), seed=1
    )
    print(hy_report.summary())
    print(f"  Q (HPSO-GA): {[round(x, 1) for x in hy_report.best_solution]}")
    pso_v_hy = 100 * (pso_report.best_fitness - hy_report.best_fitness) / pso_report.best_fitness
    print(f"  Hybrid vs PSO improvement: {pso_v_hy:+.2f}%")

    # ---- BFD ----------------------------------------------------------
    print("\n[5/5] Bessel-Fourier Descriptors — Shape Classification")
    print("-" * 78)
    bfd_report = run_bfd_pipeline(BFDConfig(num_coeffs=14, lambda_value=0.22), seed=7)
    print(bfd_report.summary())
    print(f"  Test accuracy : {bfd_report.extra['test_accuracy']:.4f}")
    print(f"  Classes       : {bfd_report.extra['class_names']}")

    # ---- Comparative table -------------------------------------------
    print("\n" + "=" * 78)
    print(" COMPARATIVE RESULTS")
    print("=" * 78)
    rows = [
        ("AGOA",          agoa_report.problem,  f"{agoa_report.best_fitness:,.2f}",
         agoa_report.iterations, f"{agoa_report.wall_time_seconds:.2f}s"),
        ("SA (weighted)", sa_w.problem,         f"{sa_w.best_fitness:,.2f}",
         sa_w.iterations,    f"{sa_w.wall_time_seconds:.2f}s"),
        ("MOSA archive",  sa_a.problem,         f"{sa_a.best_fitness:,.2f}",
         sa_a.iterations,    f"{sa_a.wall_time_seconds:.2f}s"),
        ("PSO",           pso_report.problem,   f"{pso_report.best_fitness:,.2f}",
         pso_report.iterations, f"{pso_report.wall_time_seconds:.2f}s"),
        ("Hybrid PSO-GA", hy_report.problem,    f"{hy_report.best_fitness:,.2f}",
         hy_report.iterations,  f"{hy_report.wall_time_seconds:.2f}s"),
        ("BFD+SVM",       bfd_report.problem,
         f"acc={bfd_report.extra['test_accuracy']:.3f}",
         bfd_report.iterations, f"{bfd_report.wall_time_seconds:.2f}s"),
    ]
    header = f"{'Algorithm':<16} {'Problem':<28} {'Fitness':<14} {'Iters':>6} {'Time':>8}"
    print(header)
    print("-" * len(header))
    for r in rows:
        print(f"{r[0]:<16} {r[1]:<28} {r[2]:<14} {r[3]:>6} {r[4]:>8}")
    print()


if __name__ == "__main__":
    main()

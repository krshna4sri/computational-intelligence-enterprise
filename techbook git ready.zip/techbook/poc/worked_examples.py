"""
Worked examples — run every algorithm on the CSV datasets in poc/datasets/
and print numerical results that match Appendix D of the book.

Run from the techbook/ directory:

    python -m poc.worked_examples
"""

from __future__ import annotations

import numpy as np

from poc.agoa.agoa_scm import AGOAConfig, SupplyNetworkProblem, run_agoa
from poc.bessel_bfd.bfd_classifier import BFDConfig, run_bfd_pipeline
from poc.common import (
    load_inventory_csv,
    load_supply_network_csv,
    load_transport_csv,
    set_seed,
)
from poc.hybrid_pso_ga.hybrid import HybridConfig, run_hybrid_pso_ga
from poc.pso.pso_inventory import InventoryProblem, PSOConfig, run_pso
from poc.simulated_annealing.mosa_scm import (
    SAConfig,
    TransportProblem,
    run_weight_sweep_mosa,
    run_weighted_sum_sa,
)


def section(title: str) -> None:
    print("\n" + "=" * 78)
    print(f" {title}")
    print("=" * 78)


# ---------------------------------------------------------------------------
# D.1 — AGOA on the CSV supply network
# ---------------------------------------------------------------------------

def worked_example_agoa() -> None:
    section("D.1  AGOA on CSV supply-network dataset")
    data = load_supply_network_csv()
    print(f"Suppliers : {list(data['supplier_names'])}")
    print(f"Plants    : {list(data['plant_names'])}")
    print(f"DCs       : {list(data['dc_names'])}")
    print(f"SP cost matrix ({data['n_suppliers']}x{data['n_plants']}):")
    print(np.array2string(data["sp_cost"], precision=2))
    print(f"PD cost matrix ({data['n_plants']}x{data['n_dcs']}):")
    print(np.array2string(data["pd_cost"], precision=2))

    set_seed(42)
    problem = SupplyNetworkProblem(data=data)
    report = run_agoa(problem, AGOAConfig(population_size=80, generations=200), seed=42)
    print("\n" + report.summary())
    sp = report.best_solution["supplier_to_plant"]
    pd_ = report.best_solution["plant_to_dc"]
    print("\nDecoded assignment:")
    for s, p in enumerate(sp):
        print(f"  {data['supplier_names'][s]:<22} -> {data['plant_names'][p]}")
    for p, d in enumerate(pd_):
        print(f"  {data['plant_names'][p]:<22} -> {data['dc_names'][d]}")


# ---------------------------------------------------------------------------
# D.2 — Multi-Objective SA on CSV transport dataset
# ---------------------------------------------------------------------------

def worked_example_sa() -> None:
    section("D.2  Multi-Objective SA on CSV transport dataset")
    # Use the diesel-rail modes file so a genuine cost-vs-emissions trade-off exists.
    # (With the default electric-rail modes, rail strictly dominates both objectives
    #  and the Pareto front collapses to a single point.)
    from pathlib import Path as _P
    modes_path = _P(__file__).resolve().parent / "datasets" / "transport_modes_diesel_rail.csv"
    data = load_transport_csv(modes_path=modes_path)
    print(f"Cities: {list(data['city_names'])}")
    print(f"Modes : {list(data['mode_names'])} "
          f"(costs: {data['mode_cost_per_km_per_unit'].tolist()}, "
          f"emissions: {data['mode_emissions_per_km_per_unit'].tolist()})")

    problem = TransportProblem(data=data)
    cfg = SAConfig(initial_temperature=2000, cooling_rate=0.98, iterations=800)

    set_seed(7)
    r_mid = run_weighted_sum_sa(problem, SAConfig(**{**cfg.__dict__, "w_cost": 0.5, "w_co2": 0.5}), seed=7)
    print(f"\nBalanced (α=0.5): cost=${r_mid.extra['best_cost']:,.2f}  "
          f"CO₂={r_mid.extra['best_co2_kg']:,.2f} kg")

    r_cheap = run_weighted_sum_sa(problem, SAConfig(**{**cfg.__dict__, "w_cost": 0.95, "w_co2": 0.05}), seed=7)
    print(f"Cost-focused (α=0.95): cost=${r_cheap.extra['best_cost']:,.2f}  "
          f"CO₂={r_cheap.extra['best_co2_kg']:,.2f} kg")

    r_green = run_weighted_sum_sa(problem, SAConfig(**{**cfg.__dict__, "w_cost": 0.05, "w_co2": 0.95}), seed=7)
    print(f"Green-focused (α=0.05): cost=${r_green.extra['best_cost']:,.2f}  "
          f"CO₂={r_green.extra['best_co2_kg']:,.2f} kg")

    r_sweep = run_weight_sweep_mosa(problem, cfg, seed=7, n_weights=11)
    print(f"\nWeight-sweep Pareto front size: {r_sweep.extra['pareto_front_size']}")
    print(f"Knee point: cost=${r_sweep.extra['knee_cost']:,.2f}  "
          f"CO₂={r_sweep.extra['knee_co2_kg']:,.2f} kg")
    print("Front points (sorted by cost):")
    for pt in r_sweep.extra["pareto_front"]:
        print(f"  cost=${pt['cost']:>11,.2f}   CO₂={pt['co2_kg']:>11,.2f} kg")


# ---------------------------------------------------------------------------
# D.3 — PSO on CSV inventory dataset
# ---------------------------------------------------------------------------

def worked_example_pso() -> None:
    section("D.3  PSO on CSV inventory dataset")
    data = load_inventory_csv()
    print(f"{'Product':<12} {'Demand':>8} {'Hold':>6} {'Order':>7} {'Short':>7}")
    for i in range(len(data["product_name"])):
        print(f"{data['product_name'][i]:<12} "
              f"{int(data['historical_demand'][i]):>8} "
              f"{data['holding_cost'][i]:>6.2f} "
              f"{data['ordering_cost'][i]:>7.2f} "
              f"{data['shortage_cost'][i]:>7.2f}")

    # EOQ reference (no-shortage analytical optimum)
    eoq = np.sqrt(2 * data["historical_demand"] * data["ordering_cost"] / data["holding_cost"])
    print(f"\nAnalytical EOQ (no shortage): {[round(float(q), 1) for q in eoq]}")

    set_seed(42)
    problem = InventoryProblem(data=data)
    report = run_pso(problem, PSOConfig(n_particles=30, iterations=300), seed=42)
    print(f"\n{report.summary()}")
    print(f"Recommended Q: {[round(float(q), 1) for q in report.best_solution]}")


# ---------------------------------------------------------------------------
# D.4 — Hybrid PSO-GA on CSV inventory dataset (head-to-head)
# ---------------------------------------------------------------------------

def worked_example_hybrid() -> None:
    section("D.4  Hybrid PSO-GA vs PSO (same CSV inventory dataset)")
    data = load_inventory_csv()
    problem = InventoryProblem(data=data)

    rs_pso, rs_hy = [], []
    for seed in [1, 2, 3, 4, 5]:
        set_seed(seed)
        r1 = run_pso(problem, PSOConfig(n_particles=30, iterations=200), seed=seed)
        set_seed(seed)
        r2 = run_hybrid_pso_ga(problem, HybridConfig(n_particles=30, iterations=200), seed=seed)
        rs_pso.append(r1.best_fitness)
        rs_hy.append(r2.best_fitness)
        print(f"  seed={seed}:  PSO={r1.best_fitness:>9.2f}   "
              f"Hybrid={r2.best_fitness:>9.2f}   "
              f"Δ={r1.best_fitness - r2.best_fitness:+.2f}")
    print(f"\nMean PSO    : {np.mean(rs_pso):.2f}")
    print(f"Mean Hybrid : {np.mean(rs_hy):.2f}")


# ---------------------------------------------------------------------------
# D.5 — BFD shape-classification pipeline
# ---------------------------------------------------------------------------

def worked_example_bfd() -> None:
    section("D.5  BFD + Linear SVM on synthetic shape dataset")
    report = run_bfd_pipeline(BFDConfig(num_coeffs=14, lambda_value=0.22), seed=7)
    print(report.summary())
    print(f"  Test accuracy : {report.extra['test_accuracy']:.4f}")
    print(f"  Classes       : {report.extra['class_names']}")
    print(f"  Train / Test  : {report.extra['n_train']} / {report.extra['n_test']}")


def main() -> None:
    worked_example_agoa()
    worked_example_sa()
    worked_example_pso()
    worked_example_hybrid()
    worked_example_bfd()


if __name__ == "__main__":
    main()

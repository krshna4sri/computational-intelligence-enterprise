"""Bessel-Fourier Descriptors for image pattern recognition."""

"""
Particle Swarm Optimization for Inventory Management
====================================================

A working POC of PSO applied to multi-product inventory optimization.
The decision variables are per-product **order quantities** (continuous),
and the fitness is the total supply-chain inventory cost:

    cost(Q) = sum_i ( holding_i * Q_i
                    + ordering_i * (demand_i / max(Q_i, 1))
                    + shortage_i * max(0, demand_i - Q_i) )

This is a richer formulation than a toy quadratic: the ordering-cost term
uses the classical EOQ style (cost per cycle * cycles per period), and the
shortage term penalizes under-ordering.

Run it
------
    python -m poc.pso.pso_inventory
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np

from poc.common import (
    RunReport,
    make_inventory_dataset,
    save_convergence_plot,
    set_seed,
    stopwatch,
)


# ---------------------------------------------------------------------------
# Problem
# ---------------------------------------------------------------------------

@dataclass
class InventoryProblem:
    data: dict

    @property
    def n_products(self) -> int:
        return len(self.data["historical_demand"])

    def fitness(self, Q: np.ndarray) -> float:
        d = self.data["historical_demand"]
        h = self.data["holding_cost"]
        o = self.data["ordering_cost"]
        s = self.data["shortage_cost"]

        Q = np.maximum(Q, 1.0)  # guard against zero / negative
        holding = np.sum(h * Q / 2.0)                      # average inventory
        ordering = np.sum(o * d / Q)                       # orders per period
        shortage = np.sum(s * np.maximum(0.0, d - Q))
        return float(holding + ordering + shortage)


# ---------------------------------------------------------------------------
# PSO core
# ---------------------------------------------------------------------------

@dataclass
class PSOConfig:
    n_particles: int = 30
    iterations: int = 200
    w_start: float = 0.9
    w_end: float = 0.4
    c1: float = 1.5
    c2: float = 1.5
    v_max_frac: float = 0.2
    lower: float = 1.0
    upper: float = 3000.0


def run_pso(
    problem: InventoryProblem, config: PSOConfig = PSOConfig(), seed: int = 0
) -> RunReport:
    rng = np.random.default_rng(seed)
    n = config.n_particles
    d = problem.n_products

    # Initialize
    x = rng.uniform(config.lower, config.upper, size=(n, d))
    v_max = config.v_max_frac * (config.upper - config.lower)
    v = rng.uniform(-v_max, v_max, size=(n, d))

    pbest = x.copy()
    pbest_f = np.array([problem.fitness(xi) for xi in x])
    g_idx = int(np.argmin(pbest_f))
    gbest = pbest[g_idx].copy()
    gbest_f = float(pbest_f[g_idx])

    trace: List[float] = [gbest_f]

    with stopwatch() as elapsed:
        for it in range(config.iterations):
            # Linear inertia decay
            w = config.w_start + (config.w_end - config.w_start) * (it / max(1, config.iterations - 1))

            r1 = rng.random(size=(n, d))
            r2 = rng.random(size=(n, d))

            v = (
                w * v
                + config.c1 * r1 * (pbest - x)
                + config.c2 * r2 * (gbest - x)
            )
            np.clip(v, -v_max, v_max, out=v)

            x = x + v
            np.clip(x, config.lower, config.upper, out=x)

            f = np.array([problem.fitness(xi) for xi in x])
            improved = f < pbest_f
            pbest[improved] = x[improved]
            pbest_f[improved] = f[improved]

            g_idx = int(np.argmin(pbest_f))
            if pbest_f[g_idx] < gbest_f:
                gbest = pbest[g_idx].copy()
                gbest_f = float(pbest_f[g_idx])

            trace.append(gbest_f)
        total_time = elapsed()

    return RunReport(
        algorithm="PSO",
        problem="inventory_management",
        best_fitness=gbest_f,
        best_solution=gbest.tolist(),
        iterations=config.iterations,
        wall_time_seconds=total_time,
        convergence_trace=trace,
        extra={
            "order_quantities": gbest.tolist(),
            "demand": problem.data["historical_demand"].tolist(),
        },
    )


# ---------------------------------------------------------------------------
# Demo entry point
# ---------------------------------------------------------------------------

def main() -> None:
    set_seed(42)
    data = make_inventory_dataset(n_products=5, seed=42)
    problem = InventoryProblem(data=data)

    report = run_pso(problem, PSOConfig(n_particles=40, iterations=250))
    print(report.summary())
    print("Demand     :", [round(x, 1) for x in problem.data["historical_demand"].tolist()])
    print("Order Qty Q:", [round(x, 1) for x in report.best_solution])

    save_convergence_plot(
        report.convergence_trace,
        "/tmp/pso_convergence.png",
        "PSO — Inventory Total-Cost Convergence",
    )


if __name__ == "__main__":
    main()

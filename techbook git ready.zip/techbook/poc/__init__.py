"""POC implementations for the tech book."""

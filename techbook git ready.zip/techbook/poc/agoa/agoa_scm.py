"""
AGOA — Adaptive Genetic Optimization Algorithm
==============================================

A working POC of the Adaptive Genetic Optimization Algorithm applied to a
three-tier supply network (suppliers -> plants -> distribution centers).

The "adaptive" part of AGOA — what distinguishes it from a textbook GA — is
that **mutation and crossover rates are tuned online** based on population
diversity and the recent improvement rate. When the population stagnates
(diversity drops / no improvement), mutation rate rises to escape the local
optimum. When the population is exploring well, mutation shrinks so good
solutions can be exploited.

Problem encoding
----------------
A chromosome is an integer vector of length (n_suppliers + n_plants):

    [plant_for_supplier_0, ..., plant_for_supplier_{S-1},
     dc_for_plant_0, ..., dc_for_plant_{P-1}]

Each gene is bounded by the downstream tier size. The objective minimizes:

    total_cost = supplier->plant shipping cost
               + plant->dc shipping cost
               + fixed operating cost of every opened plant
               + capacity-violation penalty

Run it
------
    python -m poc.agoa.agoa_scm
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

from poc.common import (
    RunReport,
    make_supply_network,
    save_convergence_plot,
    set_seed,
    stopwatch,
)


# ---------------------------------------------------------------------------
# Problem definition
# ---------------------------------------------------------------------------

@dataclass
class SupplyNetworkProblem:
    """Wraps the network data and exposes a fitness function."""

    data: dict
    penalty_weight: float = 5000.0

    @property
    def chrom_length(self) -> int:
        return self.data["n_suppliers"] + self.data["n_plants"]

    def random_chromosome(self, rng: np.random.Generator) -> np.ndarray:
        s = self.data["n_suppliers"]
        p = self.data["n_plants"]
        d = self.data["n_dcs"]
        sup_to_plant = rng.integers(0, p, size=s)
        plant_to_dc = rng.integers(0, d, size=p)
        return np.concatenate([sup_to_plant, plant_to_dc])

    def decode(self, chrom: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        s = self.data["n_suppliers"]
        return chrom[:s], chrom[s:]

    def total_cost(self, chrom: np.ndarray) -> float:
        sup_to_plant, plant_to_dc = self.decode(chrom)

        sp_cost = self.data["sp_cost"]     # (S, P)
        pd_cost = self.data["pd_cost"]     # (P, D)
        sup_cap = self.data["supplier_capacity"]
        plant_cap = self.data["plant_capacity"]
        dc_demand = self.data["dc_demand"]
        fixed = self.data["fixed_plant_cost"]

        # Ship all supplier capacity to assigned plant
        ship_sp = 0.0
        plant_inflow = np.zeros(self.data["n_plants"])
        for s_idx, p_idx in enumerate(sup_to_plant):
            q = sup_cap[s_idx]
            ship_sp += q * sp_cost[s_idx, p_idx]
            plant_inflow[p_idx] += q

        # Ship each plant's inflow to its assigned DC
        ship_pd = 0.0
        dc_inflow = np.zeros(self.data["n_dcs"])
        for p_idx, d_idx in enumerate(plant_to_dc):
            q = plant_inflow[p_idx]
            ship_pd += q * pd_cost[p_idx, d_idx]
            dc_inflow[d_idx] += q

        # Fixed cost for plants that actually receive flow
        used_plants = np.unique(sup_to_plant)
        fixed_cost = float(fixed[used_plants].sum())

        # Penalties
        plant_over = np.maximum(0.0, plant_inflow - plant_cap).sum()
        dc_short = np.maximum(0.0, dc_demand - dc_inflow).sum()
        penalty = self.penalty_weight * (plant_over + dc_short)

        return ship_sp + ship_pd + fixed_cost + penalty


# ---------------------------------------------------------------------------
# AGOA core
# ---------------------------------------------------------------------------

@dataclass
class AGOAConfig:
    population_size: int = 80
    generations: int = 200
    tournament_k: int = 3
    elite_k: int = 2
    base_mutation_rate: float = 0.05
    base_crossover_rate: float = 0.80
    # Adaptive bounds
    min_mutation_rate: float = 0.01
    max_mutation_rate: float = 0.40
    # Adaptation: how strongly diversity/stagnation tweak rates
    diversity_gain: float = 0.8
    stagnation_gain: float = 1.5
    stagnation_window: int = 8


def _tournament_select(
    pop: np.ndarray, fitness: np.ndarray, k: int, rng: np.random.Generator
) -> np.ndarray:
    idx = rng.integers(0, len(pop), size=k)
    winner = idx[int(np.argmin(fitness[idx]))]
    return pop[winner].copy()


def _two_point_crossover(
    a: np.ndarray, b: np.ndarray, rng: np.random.Generator
) -> Tuple[np.ndarray, np.ndarray]:
    n = len(a)
    if n < 3:
        return a.copy(), b.copy()
    i, j = sorted(rng.integers(1, n, size=2).tolist())
    c1 = np.concatenate([a[:i], b[i:j], a[j:]])
    c2 = np.concatenate([b[:i], a[i:j], b[j:]])
    return c1, c2


def _mutate(
    chrom: np.ndarray,
    rate: float,
    problem: SupplyNetworkProblem,
    rng: np.random.Generator,
) -> np.ndarray:
    s = problem.data["n_suppliers"]
    p = problem.data["n_plants"]
    d = problem.data["n_dcs"]
    out = chrom.copy()
    for i in range(len(out)):
        if rng.random() < rate:
            upper = p if i < s else d
            out[i] = int(rng.integers(0, upper))
    return out


def _population_diversity(pop: np.ndarray) -> float:
    """Fraction of gene positions whose unique-value count exceeds 1."""
    unique_per_gene = np.array([len(np.unique(pop[:, j])) for j in range(pop.shape[1])])
    # Normalize by population size
    return float(np.mean(unique_per_gene) / max(pop.shape[0], 1))


def run_agoa(
    problem: SupplyNetworkProblem,
    config: AGOAConfig = AGOAConfig(),
    seed: int = 0,
) -> RunReport:
    rng = np.random.default_rng(seed)

    # Initialize population
    pop = np.vstack(
        [problem.random_chromosome(rng) for _ in range(config.population_size)]
    )
    fitness = np.array([problem.total_cost(c) for c in pop])

    trace: List[float] = [float(fitness.min())]
    best_idx = int(np.argmin(fitness))
    best = pop[best_idx].copy()
    best_fit = float(fitness[best_idx])

    mutation_rate = config.base_mutation_rate
    crossover_rate = config.base_crossover_rate
    stagnation = 0
    last_best = best_fit

    with stopwatch() as elapsed:
        for gen in range(config.generations):
            new_pop = []

            # Elitism
            elite_idx = np.argsort(fitness)[: config.elite_k]
            for e in elite_idx:
                new_pop.append(pop[e].copy())

            while len(new_pop) < config.population_size:
                p1 = _tournament_select(pop, fitness, config.tournament_k, rng)
                p2 = _tournament_select(pop, fitness, config.tournament_k, rng)

                if rng.random() < crossover_rate:
                    c1, c2 = _two_point_crossover(p1, p2, rng)
                else:
                    c1, c2 = p1.copy(), p2.copy()

                c1 = _mutate(c1, mutation_rate, problem, rng)
                c2 = _mutate(c2, mutation_rate, problem, rng)
                new_pop.append(c1)
                if len(new_pop) < config.population_size:
                    new_pop.append(c2)

            pop = np.vstack(new_pop)
            fitness = np.array([problem.total_cost(c) for c in pop])

            gen_best = float(fitness.min())
            if gen_best < best_fit - 1e-9:
                best_fit = gen_best
                best = pop[int(np.argmin(fitness))].copy()
                stagnation = 0
            else:
                stagnation += 1

            trace.append(best_fit)

            # ---- Adaptive rate update ---------------------------------
            diversity = _population_diversity(pop)
            # Low diversity -> raise mutation. High diversity -> lower mutation.
            mut = config.base_mutation_rate * (
                1.0 + config.diversity_gain * (0.5 - diversity)
            )
            # Long stagnation -> further raise mutation
            if stagnation > config.stagnation_window:
                mut *= 1.0 + config.stagnation_gain * math.log1p(
                    stagnation - config.stagnation_window
                )
            mutation_rate = float(
                np.clip(mut, config.min_mutation_rate, config.max_mutation_rate)
            )

            # Shrink crossover slightly when stagnating to let mutation drive
            crossover_rate = float(
                np.clip(
                    config.base_crossover_rate - 0.02 * max(0, stagnation - 5),
                    0.4,
                    0.95,
                )
            )

            last_best = best_fit

        total_time = elapsed()

    sup_to_plant, plant_to_dc = problem.decode(best)
    return RunReport(
        algorithm="AGOA",
        problem="three_tier_supply_network",
        best_fitness=best_fit,
        best_solution={
            "supplier_to_plant": sup_to_plant.tolist(),
            "plant_to_dc": plant_to_dc.tolist(),
        },
        iterations=config.generations,
        wall_time_seconds=total_time,
        convergence_trace=trace,
        extra={
            "final_mutation_rate": mutation_rate,
            "final_crossover_rate": crossover_rate,
        },
    )


# ---------------------------------------------------------------------------
# Demo entry point
# ---------------------------------------------------------------------------

def main() -> None:
    set_seed(42)
    data = make_supply_network(n_suppliers=5, n_plants=3, n_dcs=6, seed=11)
    problem = SupplyNetworkProblem(data=data)
    report = run_agoa(problem, AGOAConfig(population_size=80, generations=150))
    print(report.summary())
    print("Supplier -> Plant:", report.best_solution["supplier_to_plant"])
    print("Plant    -> DC   :", report.best_solution["plant_to_dc"])
    save_convergence_plot(
        report.convergence_trace,
        "/tmp/agoa_convergence.png",
        "AGOA — Supply Network Total Cost Convergence",
    )


if __name__ == "__main__":
    main()

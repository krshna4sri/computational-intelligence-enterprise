"""AGOA — Adaptive Genetic Optimization Algorithm."""

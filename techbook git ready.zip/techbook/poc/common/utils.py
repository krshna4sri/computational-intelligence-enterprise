"""
Common utilities shared across all algorithm POCs.

This module provides:
  - A unified `RunReport` dataclass so every algorithm produces comparable output
  - Deterministic seeding helpers
  - Synthetic supply-chain dataset generators (so the POCs run without external CSVs)
  - A lightweight timing context manager

Author: Based on the research preprints by Ravi Chandra Srikanth Cherukupalli
"""

from __future__ import annotations

import contextlib
import json
import random
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import numpy as np


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------

def set_seed(seed: int) -> None:
    """Seed both Python `random` and NumPy's default generator."""
    random.seed(seed)
    np.random.seed(seed)


# ---------------------------------------------------------------------------
# Unified run report
# ---------------------------------------------------------------------------

@dataclass
class RunReport:
    """Structured result for any optimization run.

    Every POC in this book returns an instance of `RunReport` so results can
    be compared, logged, or serialized uniformly.
    """

    algorithm: str
    problem: str
    best_fitness: float
    best_solution: Any
    iterations: int
    wall_time_seconds: float
    convergence_trace: List[float] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_json(self, path: Optional[str | Path] = None) -> str:
        payload = asdict(self)
        # Convert numpy arrays to lists for JSON
        if isinstance(payload["best_solution"], np.ndarray):
            payload["best_solution"] = payload["best_solution"].tolist()
        text = json.dumps(payload, indent=2, default=str)
        if path is not None:
            Path(path).write_text(text)
        return text

    def summary(self) -> str:
        return (
            f"[{self.algorithm}] problem={self.problem} "
            f"best_fitness={self.best_fitness:.4f} "
            f"iters={self.iterations} "
            f"time={self.wall_time_seconds:.2f}s"
        )


# ---------------------------------------------------------------------------
# Timing
# ---------------------------------------------------------------------------

@contextlib.contextmanager
def stopwatch():
    """Context manager that yields a callable returning elapsed seconds."""
    start = time.perf_counter()
    yield lambda: time.perf_counter() - start


# ---------------------------------------------------------------------------
# Synthetic datasets — so POCs run standalone
# ---------------------------------------------------------------------------

def make_inventory_dataset(
    n_products: int = 5, seed: int = 42
) -> Dict[str, np.ndarray]:
    """Generate a synthetic multi-product inventory dataset.

    Returns arrays for historical demand, holding cost, ordering cost,
    shortage cost, and lead time.
    """
    rng = np.random.default_rng(seed)
    return {
        "product_id": np.arange(1, n_products + 1),
        "historical_demand": rng.integers(800, 2200, size=n_products).astype(float),
        "holding_cost": rng.uniform(0.3, 0.7, size=n_products).round(2),
        "ordering_cost": rng.uniform(40, 80, size=n_products).round(2),
        "shortage_cost": rng.uniform(1.0, 3.0, size=n_products).round(2),
        "lead_time": rng.integers(2, 10, size=n_products).astype(float),
    }


def make_transportation_network(
    n_locations: int = 6, seed: int = 7
) -> Dict[str, np.ndarray]:
    """Generate a synthetic transportation network with distances,
    per-unit costs, and per-unit emissions for three modes (truck/rail/air).
    """
    rng = np.random.default_rng(seed)
    dist = rng.integers(50, 2000, size=(n_locations, n_locations)).astype(float)
    np.fill_diagonal(dist, 0)
    dist = (dist + dist.T) / 2  # symmetric

    # Cost per km per unit, by mode
    mode_cost = np.array([0.15, 0.08, 0.80])          # truck, rail, air
    mode_emissions = np.array([0.12, 0.03, 0.55])     # kg CO2 per km per unit
    mode_speed_kmh = np.array([70.0, 50.0, 800.0])

    demand = rng.integers(80, 400, size=(n_locations, n_locations)).astype(float)
    np.fill_diagonal(demand, 0)

    return {
        "distance_km": dist,
        "demand_units": demand,
        "mode_cost_per_km_per_unit": mode_cost,
        "mode_emissions_per_km_per_unit": mode_emissions,
        "mode_speed_kmh": mode_speed_kmh,
        "mode_names": np.array(["truck", "rail", "air"]),
    }


def make_supply_network(
    n_suppliers: int = 4, n_plants: int = 3, n_dcs: int = 5, seed: int = 11
) -> Dict[str, Any]:
    """Generate a synthetic three-tier supply network for AGOA.

    The network has suppliers -> plants -> distribution centers. AGOA will
    choose an integer assignment vector that links each stage.
    """
    rng = np.random.default_rng(seed)
    return {
        "n_suppliers": n_suppliers,
        "n_plants": n_plants,
        "n_dcs": n_dcs,
        "supplier_capacity": rng.integers(400, 1200, n_suppliers).astype(float),
        "plant_capacity": rng.integers(500, 1500, n_plants).astype(float),
        "dc_demand": rng.integers(200, 900, n_dcs).astype(float),
        "sp_cost": rng.uniform(1.0, 4.0, (n_suppliers, n_plants)).round(2),
        "pd_cost": rng.uniform(1.5, 5.0, (n_plants, n_dcs)).round(2),
        "fixed_plant_cost": rng.uniform(2000, 6000, n_plants).round(0),
    }


# ---------------------------------------------------------------------------
# Mini plotting helper (headless-safe)
# ---------------------------------------------------------------------------

def save_convergence_plot(trace: Sequence[float], path: str, title: str) -> None:
    """Save a convergence curve. Uses Agg backend so it works headless."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(trace, linewidth=1.8)
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Best fitness so far")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)

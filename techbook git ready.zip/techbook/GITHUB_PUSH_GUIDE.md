# Pushing this repository to GitHub

This guide walks you through putting the `techbook/` directory under Git
version control and publishing it to GitHub. Everything happens from your own
laptop — the book's build environment cannot reach github.com directly, so
this is a one-time copy-paste workflow at your end.

The whole thing takes under five minutes.

---

## Prerequisites

1. **Git installed.** Verify by running `git --version` in a terminal.
   If missing, install from https://git-scm.com/downloads.

2. **A GitHub account.** If you don't have one, sign up at https://github.com/signup.

3. **Authentication configured.** Pick one of:
   - **HTTPS + Personal Access Token** (easiest). Generate at
     https://github.com/settings/tokens → "Generate new token (classic)"
     → tick `repo` scope → copy the token. Git will prompt for it as your
     password on first push.
   - **SSH key.** Instructions at https://docs.github.com/en/authentication/connecting-to-github-with-ssh.

4. **Git configured with your name + email** (one-time):
   ```bash
   git config --global user.name  "Ravi Chandra Srikanth Cherukupalli"
   git config --global user.email "your-email@example.com"
   ```

---

## Step 1 — Unpack the deliverables

Download `techbook_complete.zip` from the chat and unpack it anywhere on your
laptop. You should end up with a `techbook_pkg/` folder containing `poc/`,
`kdp/`, `book/`, and supporting files.

```bash
unzip techbook_complete.zip
cd techbook_pkg
```

> **Rename tip.** If you prefer a cleaner directory name, rename
> `techbook_pkg` to something like `computational-intelligence-enterprise`
> before the next step.

---

## Step 2 — Create the GitHub repository (empty)

On github.com:

1. Click the **+** icon (top right) → **New repository**.
2. Fill in:
   - **Repository name:** `computational-intelligence-enterprise`
     *(or any name you prefer — lowercase-with-dashes is conventional)*
   - **Description:** `Companion code + book for "Computational Intelligence for Enterprise Systems"`
   - **Public** or **Private** — your call. Private is fine; you can flip it later.
   - **Do NOT** initialize with a README, .gitignore, or license — we already
     have those locally. Leave all three checkboxes unchecked.
3. Click **Create repository**.

GitHub will show you a "Quick setup" page with a URL like:
```
https://github.com/<your-username>/computational-intelligence-enterprise.git
```
Copy that URL — you need it in Step 4.

---

## Step 3 — Initialize git locally

From the unpacked `techbook_pkg/` directory:

```bash
git init
git add .
git status                                  # review what's being added
git commit -m "Initial commit: book, POCs, KDP package"
```

Expected: a successful commit listing the files you just added. If Git warns
that it won't track `__pycache__/` or `node_modules/` — that's expected, the
`.gitignore` excludes them on purpose.

---

## Step 4 — Connect to GitHub and push

Paste the URL you copied in Step 2:

```bash
git branch -M main
git remote add origin https://github.com/<your-username>/computational-intelligence-enterprise.git
git push -u origin main
```

First push prompts for credentials:
- **Username:** your GitHub username
- **Password:** paste the Personal Access Token from Step 0.4
  *(not your GitHub login password — GitHub removed password auth for Git)*

After 10-20 seconds you'll see something like:
```
Enumerating objects: ... done.
Writing objects: 100% (NN/NN), MB | KB/s, done.
To https://github.com/<your-username>/computational-intelligence-enterprise.git
 * [new branch]      main -> main
branch 'main' set up to track 'origin/main'.
```

Reload your GitHub repo page — every file should be there.

---

## Step 5 — Recommended follow-ups

### Add a repository description and topics

On github.com, click the ⚙️ next to "About" on your repo's main page and add:

- **Description:** *(same as Step 2)*
- **Website:** your Amazon book page URL (once published)
- **Topics** *(help discoverability):* `metaheuristics`, `optimization`,
  `genetic-algorithm`, `particle-swarm-optimization`, `simulated-annealing`,
  `supply-chain`, `python`, `operations-research`

### Protect the `main` branch (if you want collaborators later)

Settings → Branches → Add rule → "Require pull request reviews before merging."
Not necessary for a solo project but useful the day someone contributes a fix.

### Add a GitHub release for each book edition

When the book goes live on KDP, create a release on GitHub with:
- Tag: `v1.0.0`
- Title: `Book v1.0 — KDP launch`
- Attach: `Computational_Intelligence_KDP_Interior.pdf` and `cover_wrap_KDP.pdf`

This gives readers a canonical download of the book artifacts matching the
code at that point.

---

## What if I want to add files later?

Standard Git workflow:

```bash
# edit some files, then...
git add <files>
git commit -m "Short description of what changed"
git push
```

---

## What if my push is rejected with "large file" errors?

Git LFS (Large File Storage) handles files over 100 MB. You probably won't
need it — the largest file in this repo (the wrap JPEG) is ~1 MB. But if you
later add high-resolution print-ready TIFFs or proof PDFs, install LFS:

```bash
git lfs install
git lfs track "*.tiff" "*.psd"
git add .gitattributes
```

---

## Troubleshooting

**"Permission denied (publickey)"** — you're using SSH but haven't added
your SSH key to GitHub. Either add the key (see Prerequisites) or switch to
HTTPS:
```bash
git remote set-url origin https://github.com/<your-username>/<repo>.git
```

**"fatal: not a git repository"** — you're running `git` commands from
outside the folder. `cd` into `techbook_pkg/` first.

**"Updates were rejected because the remote contains work that you do not have locally"**
— you probably initialized the GitHub repo with a README or LICENSE despite
the Step 2 note. Fix it in one of two ways:
```bash
git pull origin main --rebase    # pull remote changes, replay yours on top
git push
```
or, if you're sure you want your local version to win:
```bash
git push --force-with-lease
```

---

That's it. Any issues, the GitHub docs at https://docs.github.com/ are
excellent — searching the exact error message usually lands on the right page.

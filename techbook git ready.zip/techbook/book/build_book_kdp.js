// build_book_kdp.js — KDP paperback interior build
// Trim: 6" x 9" = 8640 x 12960 DXA (nominal). We use height 12916 DXA to
// compensate for the ~0.03" overshoot LibreOffice adds on DOCX -> PDF export,
// so the rendered PDF lands at exactly 432 x 648 pt (6.00" x 9.00"), which is
// what KDP's trim-size check requires.
// Margins: 0.75" inside (gutter), 0.5" outside, 0.75" top/bottom
// Mirror margins enabled so the inside (gutter) is always nearest the spine.

// IMPORTANT: set this env var BEFORE any require() of helpers so that tables,
// formula boxes and code blocks clamp to the 4.75" KDP content width.
process.env.KDP_BUILD = '1';

const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, Header, Footer,
  AlignmentType, PageNumber, LevelFormat, HeadingLevel,
  BorderStyle, PageBreak, PageOrientation,
} = require('docx');

const A = require('./content_part_a');
const B = require('./content_part_b');
const C = require('./content_part_c');
const D = require('./content_part_d');
const E = require('./content_part_e');
const { FONT, ACCENT } = require('./helpers');

// ---------------------------------------------------------------------------
// KDP 6x9 paperback page setup
// ---------------------------------------------------------------------------
const KDP_PAGE = {
  size:   { width: 8640, height: 12945 },     // 6.00" x 8.9694" DXA; after LO PDF conversion -> 6.00" x 9.00"
  margin: {
    top:    1080,                              // 0.75"
    bottom: 1080,                              // 0.75"
    right:   720,                              // 0.5"   outside
    left:   1080,                              // 0.75"  inside (gutter)
    header:  540,                              // 0.375"
    footer:  540,
    mirror:  true,                             // mirror margins for duplex
  },
};

// ---------------------------------------------------------------------------
// Copyright page (KDP requires a clean copyright page with imprint + ISBN line)
// ---------------------------------------------------------------------------
const kdpCopyrightPage = [
  new Paragraph({ pageBreakBefore: true, spacing: { before: 5600 }, alignment: AlignmentType.LEFT, children: [
    new TextRun({ text: "Computational Intelligence for Enterprise Systems", font: FONT, size: 24, bold: true }),
  ]}),
  new Paragraph({ spacing: { before: 80 }, children: [
    new TextRun({ text: "Advanced Optimization Algorithms with Working Prototypes", font: FONT, size: 20, italics: true, color: "595959" }),
  ]}),
  new Paragraph({ spacing: { before: 600 }, children: [
    new TextRun({ text: "First Edition, 2026", font: FONT, size: 20 }),
  ]}),
  new Paragraph({ spacing: { before: 600 }, children: [
    new TextRun({ text: "© 2024–2026 Ravi Chandra Srikanth Cherukupalli. All rights reserved.", font: FONT, size: 20 }),
  ]}),
  new Paragraph({ spacing: { before: 280 }, children: [
    new TextRun({ text: "No part of this publication may be reproduced, stored in a retrieval system, or transmitted in any form or by any means — electronic, mechanical, photocopying, recording, or otherwise — without the prior written permission of the copyright holder, except in the case of brief quotations embodied in critical reviews and certain other noncommercial uses permitted by copyright law.", font: FONT, size: 18, color: "404040" }),
  ]}),
  new Paragraph({ spacing: { before: 280 }, children: [
    new TextRun({ text: "Research preprints consolidated and extended with permission of the author. Accompanying source code released under a permissive license for educational and research use; see the companion repository for full terms.", font: FONT, size: 18, color: "404040" }),
  ]}),
  new Paragraph({ spacing: { before: 400 }, children: [
    new TextRun({ text: "Publisher: SmartApp Publishing, Rhode Island, USA", font: FONT, size: 18 }),
  ]}),
  new Paragraph({ spacing: { before: 80 }, children: [
    new TextRun({ text: "ISBN 978-X-XXXXXX-XX-X (paperback)", font: FONT, size: 18 }),
  ]}),
  new Paragraph({ spacing: { before: 40 }, children: [
    new TextRun({ text: "Printed in the United States of America.", font: FONT, size: 18, italics: true, color: "595959" }),
  ]}),
  new Paragraph({ spacing: { before: 400 }, children: [
    new TextRun({ text: "The information in this book is distributed on an \"as-is\" basis, without warranty. While every precaution has been taken in the preparation of this work, neither the author nor the publisher shall have any liability for damages arising from the use of the information contained herein.", font: FONT, size: 16, italics: true, color: "707070" }),
  ]}),
];

// ---------------------------------------------------------------------------
// Half-title / title page (KDP best practice: title page on odd, copyright on even)
// ---------------------------------------------------------------------------
const kdpTitlePage = [
  new Paragraph({ spacing: { before: 3600 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "COMPUTATIONAL", font: FONT, size: 48, bold: true, color: ACCENT, characterSpacing: 80 }),
  ]}),
  new Paragraph({ spacing: { before: 80, after: 80 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "INTELLIGENCE", font: FONT, size: 48, bold: true, color: ACCENT, characterSpacing: 80 }),
  ]}),
  new Paragraph({ spacing: { before: 120, after: 320 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "for Enterprise Systems", font: FONT, size: 34, italics: true, color: "404040" }),
  ]}),

  new Paragraph({ spacing: { before: 120, after: 0 }, alignment: AlignmentType.CENTER,
    border: { top: { style: BorderStyle.SINGLE, size: 12, color: ACCENT, space: 6 } },
    children: [ new TextRun({ text: "", font: FONT, size: 8 }) ],
  }),

  new Paragraph({ spacing: { before: 240, after: 60 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "Advanced Optimization Algorithms with Working Prototypes", font: FONT, size: 22, italics: true, color: "595959" }),
  ]}),

  new Paragraph({ spacing: { before: 2400 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "Ravi Chandra Srikanth Cherukupalli", font: FONT, size: 26, bold: true }),
  ]}),
  new Paragraph({ spacing: { before: 60 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "SAP Chief Architect  •  SmartApp Inc.", font: FONT, size: 18, italics: true, color: "707070" }),
  ]}),

  new Paragraph({ spacing: { before: 1800 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "SmartApp Publishing", font: FONT, size: 16, color: "595959" }),
  ]}),
  new Paragraph({ spacing: { before: 20 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "Rhode Island, USA", font: FONT, size: 14, italics: true, color: "707070" }),
  ]}),
];

// ---------------------------------------------------------------------------
// Compose the KDP interior
// ---------------------------------------------------------------------------
// Note: we use the same content arrays as the trade build — the chapter/part
// numbering is already correct. The only differences are (a) a KDP title page
// and copyright page replacing the front/back covers, and (b) a page size
// + mirror-margin layout.
const kdpChildren = [
  ...kdpTitlePage,
  ...kdpCopyrightPage,
  ...A.toc,
  ...A.preface,
  ...A.partI,
  ...A.ch1, ...A.ch2,
  ...E.partII_new,
  ...E.ch3_meta, ...E.ch4_stoch,
  ...A.partII,
  ...A.ch3, ...A.ch4, ...A.ch5,
  ...A.partIII,
  ...A.ch6, ...A.ch7,
  ...B.partIV,
  ...B.ch8, ...B.ch9, ...B.ch10, ...B.ch11,
  ...B.partV,
  ...B.ch12, ...B.ch13,
  ...B.partVI,
  ...B.ch14, ...B.ch15, ...B.ch16,
  ...B.appendices,
  ...B.appA, ...B.appB, ...B.appC,
  ...C.appD,
  ...D.appE,
];

const doc = new Document({
  creator: "Ravi Chandra Srikanth Cherukupalli",
  title: "Computational Intelligence for Enterprise Systems",
  description: "KDP paperback interior (6x9)",
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 38, bold: true, font: FONT, color: ACCENT },
        paragraph: { spacing: { before: 360, after: 240 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: FONT, color: ACCENT },
        paragraph: { spacing: { before: 260, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: FONT, color: "595959" },
        paragraph: { spacing: { before: 180, after: 100 }, outlineLevel: 2 } },
      { id: "Heading4", name: "Heading 4", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, italics: true, font: FONT, color: "595959" },
        paragraph: { spacing: { before: 140, after: 80 }, outlineLevel: 3 } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [
        { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 540, hanging: 280 } } } },
        { level: 1, format: LevelFormat.BULLET, text: "◦", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 1080, hanging: 280 } } } },
      ]},
      { reference: "numbers", levels: [
        { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 540, hanging: 280 } } } },
      ]},
    ],
  },
  sections: [{
    properties: { page: KDP_PAGE },
    headers: {
      default: new Header({ children: [ new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [ new TextRun({
          text: "Computational Intelligence for Enterprise Systems",
          font: FONT, size: 16, italics: true, color: "707070",
        }) ],
      })] }),
      even: new Header({ children: [ new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [ new TextRun({
          text: "Computational Intelligence for Enterprise Systems",
          font: FONT, size: 16, italics: true, color: "707070",
        }) ],
      })] }),
      first: new Header({ children: [ new Paragraph({ children: [new TextRun({ text: "" })] }) ] }),
    },
    footers: {
      default: new Footer({ children: [ new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: "707070" }),
        ],
      })] }),
      first: new Footer({ children: [ new Paragraph({ children: [new TextRun({ text: "" })] }) ] }),
    },
    children: kdpChildren,
  }],
});

Packer.toBuffer(doc).then((buffer) => {
  const out = process.argv[2] || "/home/claude/techbook/kdp/Computational_Intelligence_KDP_Interior.docx";
  fs.writeFileSync(out, buffer);
  console.log("Wrote KDP interior:", out, "(" + buffer.length + " bytes)");
}).catch((err) => {
  console.error("Failed:", err);
  process.exit(1);
});

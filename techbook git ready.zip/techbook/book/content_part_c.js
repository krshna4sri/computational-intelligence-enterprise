// content_part_c.js — improved front cover, back cover, Appendix D (Worked Examples)
const {
  P, PRich, H1, H2, H3, H4,
  Formula, CodeBlock, Callout,
  Bullet, Numbered, SimpleTable,
  Blank, HR, FONT, ACCENT, MONO,
} = require('./helpers');
const {
  Paragraph, TextRun, AlignmentType, PageBreak,
  BorderStyle, Table, TableRow, TableCell, WidthType, ShadingType,
} = require('docx');

// ===========================================================================
// IMPROVED FRONT COVER  (full-bleed-feel layout)
// ===========================================================================

const thickRule = (color = ACCENT) => new Paragraph({
  spacing: { before: 0, after: 0 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 36, color, space: 0 } },
  children: [new TextRun({ text: "" })],
});

const thinRule = (color = ACCENT) => new Paragraph({
  spacing: { before: 0, after: 0 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 12, color, space: 0 } },
  children: [new TextRun({ text: "" })],
});

const frontCover = [
  // Top accent bar
  new Paragraph({ spacing: { before: 0, after: 0 }, children: [new TextRun({ text: "" })] }),
  thickRule(ACCENT),
  new Paragraph({ spacing: { before: 60, after: 0 }, children: [new TextRun({ text: "" })] }),
  thinRule("7FA7D9"),

  new Paragraph({ spacing: { before: 1400 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "A TECHNICAL MANUAL", font: FONT, size: 24, bold: true, color: "7FA7D9", characterSpacing: 120 }),
  ]}),
  new Paragraph({ spacing: { before: 80, after: 60 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "VOLUME I", font: FONT, size: 20, color: "7FA7D9", characterSpacing: 80 }),
  ]}),

  new Paragraph({ spacing: { before: 600 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "Computational Intelligence", font: FONT, size: 64, bold: true, color: ACCENT }),
  ]}),
  new Paragraph({ spacing: { before: 40, after: 140 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "for Enterprise Systems", font: FONT, size: 64, bold: true, color: ACCENT }),
  ]}),

  thinRule(ACCENT),
  new Paragraph({ spacing: { before: 260 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "Advanced Optimization Algorithms", font: FONT, size: 30, italics: true, color: "404040" }),
  ]}),
  new Paragraph({ spacing: { before: 20, after: 340 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "with Working Prototypes", font: FONT, size: 30, italics: true, color: "404040" }),
  ]}),

  // Algorithm chips
  new Paragraph({ spacing: { before: 200, after: 0 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "AGOA   ◆   Simulated Annealing   ◆   Particle Swarm", font: FONT, size: 22, color: "595959", characterSpacing: 60 }),
  ]}),
  new Paragraph({ spacing: { before: 20, after: 800 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "Hybrid PSO-GA   ◆   Bessel-Fourier Descriptors", font: FONT, size: 22, color: "595959", characterSpacing: 60 }),
  ]}),

  thinRule("7FA7D9"),
  new Paragraph({ spacing: { before: 300 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "Ravi Chandra Srikanth Cherukupalli", font: FONT, size: 32, bold: true, color: "2F2F2F" }),
  ]}),
  new Paragraph({ spacing: { before: 80, after: 0 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "SAP Chief Architect  •  SmartApp Inc.  •  Rhode Island, USA", font: FONT, size: 22, italics: true, color: "707070" }),
  ]}),

  new Paragraph({ spacing: { before: 1600, after: 0 }, children: [new TextRun({ text: "" })] }),
  thinRule("7FA7D9"),
  new Paragraph({ spacing: { before: 60, after: 0 }, children: [new TextRun({ text: "" })] }),
  thickRule(ACCENT),
  new Paragraph({ children: [new PageBreak()] }),
];

// ===========================================================================
// BACK COVER
// ===========================================================================

const backCoverBlurb = (text, opts = {}) => new Paragraph({
  spacing: { before: opts.before || 0, after: opts.after || 160, line: 320 },
  alignment: AlignmentType.JUSTIFIED,
  children: [new TextRun({ text, font: FONT, size: 22, color: "2F2F2F" })],
});

const backCover = [
  new Paragraph({ pageBreakBefore: true, children: [new TextRun({ text: "" })] }),
  thickRule(ACCENT),
  new Paragraph({ spacing: { before: 60, after: 0 }, children: [new TextRun({ text: "" })] }),
  thinRule("7FA7D9"),

  new Paragraph({ spacing: { before: 700, after: 0 }, alignment: AlignmentType.LEFT, children: [
    new TextRun({ text: "BACK COVER", font: FONT, size: 18, color: "7FA7D9", characterSpacing: 120 }),
  ]}),

  new Paragraph({ spacing: { before: 160, after: 240 }, alignment: AlignmentType.LEFT, children: [
    new TextRun({ text: "When the textbook solvers break down", font: FONT, size: 40, bold: true, color: ACCENT }),
  ]}),

  backCoverBlurb("Every enterprise decision is, at some level, an optimization problem. Inventory levels. Supplier routing. Transport-mode selection. Plant configuration. For decades the default tool has been mathematical programming — rigorous, elegant, and increasingly unable to handle the reality of modern supply chains: non-linear costs, combinatorial choices, conflicting objectives, and answers needed in seconds rather than hours."),

  backCoverBlurb("This book is about what you reach for instead. Five algorithms, each drawn from a real project, each explained carefully from the mathematics down to the code: an adaptive genetic algorithm for supply-network design, multi-objective simulated annealing for cost-versus-carbon transport optimization, particle swarm for multi-product inventory, a hybrid PSO-GA for the cases where neither pure method is enough, and Bessel-Fourier descriptors for interpretable image recognition."),

  backCoverBlurb("Every algorithm comes with a working Python proof-of-concept, CSV datasets, a fitness function you can adapt, and a deployment blueprint for moving from notebook to production. The code is tested end-to-end: type one command and every algorithm in the book runs and produces the numbers quoted in the case studies. This is a practitioner's book — theory where it clarifies, code where it compiles, and candour about when to use which method."),

  new Paragraph({ spacing: { before: 280, after: 120 }, children: [
    new TextRun({ text: "What you will find inside", font: FONT, size: 28, bold: true, color: ACCENT }),
  ]}),

  new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { before: 0, after: 60 },
    children: [new TextRun({ text: "Sixteen chapters organized into six parts — Foundations, AGOA, Simulated Annealing, Swarm Intelligence, Bessel-Fourier Descriptors, and Deployment.", font: FONT, size: 22 })]}),
  new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { before: 0, after: 60 },
    children: [new TextRun({ text: "Every formula derived step-by-step and every code listing tested end-to-end, with a unified RunReport schema so results compare across algorithms.", font: FONT, size: 22 })]}),
  new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { before: 0, after: 60 },
    children: [new TextRun({ text: "Eight CSV datasets that drive worked examples in Appendix D — complete with exact numerical results you can reproduce from your own machine.", font: FONT, size: 22 })]}),
  new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { before: 0, after: 60 },
    children: [new TextRun({ text: "A reference deployment architecture, observability playbook, and four-stage rollout pattern built from real production experience.", font: FONT, size: 22 })]}),
  new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { before: 0, after: 60 },
    children: [new TextRun({ text: "A guide to when each algorithm is genuinely the right tool — and when it is not.", font: FONT, size: 22 })]}),

  new Paragraph({ spacing: { before: 280, after: 120 }, children: [
    new TextRun({ text: "Who this book is for", font: FONT, size: 28, bold: true, color: ACCENT }),
  ]}),

  backCoverBlurb("Supply-chain architects, data scientists, ML engineers, and technical managers who want both the mathematical grounding to reason about metaheuristic algorithms and the code to adapt them to their own problems. A reader comfortable with first-year calculus, basic linear algebra, and intermediate Python will find every chapter approachable."),

  new Paragraph({ spacing: { before: 240, after: 120 }, children: [
    new TextRun({ text: "About the author", font: FONT, size: 28, bold: true, color: ACCENT }),
  ]}),

  backCoverBlurb("Ravi Chandra Srikanth Cherukupalli is Chief Architect at SmartApp Inc., where he leads enterprise supply-chain and data-platform engagements for Fortune 500 clients. His work combines classical operations research with modern computational methods, and has produced the five research preprints consolidated into this volume. He holds extensive experience in SAP supply-chain architecture and is based in Rhode Island, USA."),

  new Paragraph({ spacing: { before: 400, after: 0 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "“The algorithm choice is a detail. The fitness function is the contribution.”", font: FONT, size: 22, italics: true, color: "595959" }),
  ]}),
  new Paragraph({ spacing: { before: 40, after: 800 }, alignment: AlignmentType.CENTER, children: [
    new TextRun({ text: "— from the closing chapter", font: FONT, size: 20, color: "7FA7D9" }),
  ]}),

  thinRule("7FA7D9"),
  new Paragraph({ spacing: { before: 60, after: 0 }, children: [new TextRun({ text: "" })] }),
  thickRule(ACCENT),
];

// ===========================================================================
// APPENDIX D — WORKED EXAMPLES
// ===========================================================================

const appD = [
  H1("Appendix D — Worked Examples with CSV Data and Python"),

  P("This appendix walks every algorithm in the book through a concrete run on a real CSV dataset. The source data for every example lives in poc/datasets/; the runner poc/worked_examples.py executes every example end-to-end and prints the exact numbers quoted below."),

  P("Three conventions apply throughout this appendix. First, every dataset is loaded by a call to one of the loaders in poc/common/loaders.py — the loaders return the same dict structure the synthetic generators produce, so the algorithm code is identical whether data came from a CSV or from a seeded generator. Second, every run uses a fixed seed so the numbers here can be reproduced exactly. Third, every section first states the formula, then shows the Python call, then prints the observed result."),

  // --- D.1 AGOA ----------------------------------------------------------
  H2("D.1  AGOA — three-tier supply network"),

  H3("D.1.1 The dataset"),
  P("The supply-network dataset consists of five CSV files under poc/datasets/: suppliers.csv, plants.csv, distribution_centers.csv, sp_cost_matrix.csv, and pd_cost_matrix.csv. Together they describe a five-supplier, three-plant, six-DC network."),
  Blank(),
  SimpleTable(
    ["Supplier", "Region", "Weekly capacity"],
    [
      ["SupplierCo-North", "US-Midwest",    "850"],
      ["SupplierCo-East",  "US-Northeast",  "1,100"],
      ["MetalWorks-South", "US-South",      "620"],
      ["Precision-Mex",    "Mexico",        "480"],
      ["Global-West",      "US-West",       "950"],
    ],
    [3000, 3000, 3360],
  ),
  Blank(),
  SimpleTable(
    ["Plant", "Region", "Capacity", "Fixed weekly cost"],
    [
      ["PlantAlpha", "US-Central", "1,300", "$4,500"],
      ["PlantBeta",  "US-Central", "950",   "$3,200"],
      ["PlantGamma", "US-East",    "1,400", "$5,100"],
    ],
    [2400, 2400, 2400, 2160],
  ),
  Blank(),
  SimpleTable(
    ["DC", "Region", "Weekly demand"],
    [
      ["DC-NE", "US-Northeast",    "650"],
      ["DC-MA", "US-MidAtlantic",  "480"],
      ["DC-SE", "US-Southeast",    "720"],
      ["DC-MW", "US-Midwest",      "550"],
      ["DC-SW", "US-Southwest",    "390"],
      ["DC-NW", "US-Northwest",    "430"],
    ],
    [2400, 3400, 3560],
  ),
  Blank(),
  P("The supplier-to-plant cost matrix sp_cost_matrix.csv and the plant-to-DC cost matrix pd_cost_matrix.csv complete the specification. Observed values, in dollars per unit shipped:"),
  Blank(),
  SimpleTable(
    ["sp_cost", "PlantAlpha", "PlantBeta", "PlantGamma"],
    [
      ["SupplierCo-North", "2.10", "1.85", "3.40"],
      ["SupplierCo-East",  "3.20", "2.95", "1.80"],
      ["MetalWorks-South", "2.60", "2.40", "2.85"],
      ["Precision-Mex",    "3.85", "3.60", "3.20"],
      ["Global-West",      "2.25", "2.10", "3.05"],
    ],
    [2800, 2200, 2200, 2160],
  ),
  Blank(),
  SimpleTable(
    ["pd_cost", "DC-NE", "DC-MA", "DC-SE", "DC-MW", "DC-SW", "DC-NW"],
    [
      ["PlantAlpha", "3.10", "2.90", "3.50", "2.40", "3.80", "4.10"],
      ["PlantBeta",  "3.40", "3.20", "3.75", "2.60", "3.55", "4.05"],
      ["PlantGamma", "2.20", "2.05", "2.85", "3.30", "4.50", "5.00"],
    ],
    [2000, 1226, 1226, 1226, 1226, 1228, 1228],
  ),

  H3("D.1.2 The formula, with numbers"),
  P("AGOA minimizes the total-cost function from Chapter 5:"),
  Formula([
    "f(x)  =  Σ_{s} Σ_{p}  q_s · c_{sp} · [supplier s → plant p]",
    "      + Σ_{p} Σ_{d}  Q_p · c_{pd} · [plant p → dc d]",
    "      + Σ_{p used}  F_p",
    "      + λ_penalty · ( Σ_p max(0, Q_p − cap_p) + Σ_d max(0, dem_d − in_d) )",
  ]),
  P("To make this concrete, evaluate f at one specific chromosome that AGOA might propose early in a run — the assignment [0, 2, 0, 2, 1, 3, 2, 0] meaning suppliers 1 and 3 ship to PlantAlpha, suppliers 2 and 4 to PlantGamma, supplier 5 to PlantBeta, and PlantAlpha→DC-MW, PlantBeta→DC-SE, PlantGamma→DC-NE. Reading costs from the tables above:"),
  Formula([
    "Supplier → Plant ship cost",
    "= 850·2.10 + 1100·1.80 + 620·2.60 + 480·3.20 + 950·2.10",
    "= 1785 + 1980 + 1612 + 1536 + 1995",
    "= 8,908",
  ]),
  P("Per-plant inflow: PlantAlpha = 850+620 = 1,470 units; PlantBeta = 950; PlantGamma = 1,100+480 = 1,580."),
  P("PlantAlpha inflow (1,470) exceeds capacity (1,300) by 170 units — this incurs a penalty. PlantGamma inflow (1,580) exceeds capacity (1,400) by 180. Penalty weight is 5,000 per unit (default), so the total penalty is 5000·(170+180) = 1,750,000. Plant-to-DC shipping proceeds from each plant's inflow to its assigned DC, and DC demand shortfalls trigger additional penalty. This chromosome is clearly infeasible — AGOA will push away from it."),

  H3("D.1.3 Running AGOA"),
  P("The worked-example runner loads the CSV data, constructs the problem, and runs AGOA for 200 generations with a population of 80:"),
  CodeBlock(
`from poc.common import load_supply_network_csv, set_seed
from poc.agoa.agoa_scm import SupplyNetworkProblem, AGOAConfig, run_agoa

data    = load_supply_network_csv()
set_seed(42)
problem = SupplyNetworkProblem(data=data)
report  = run_agoa(problem, AGOAConfig(population_size=80, generations=200), seed=42)`
  ),

  H3("D.1.4 Observed result"),
  CodeBlock(
`[AGOA] problem=three_tier_supply_network best_fitness=8,282,274.50 iters=200 time=0.58s

Decoded assignment:
  SupplierCo-North   -> PlantAlpha
  SupplierCo-East    -> PlantGamma
  MetalWorks-South   -> PlantAlpha
  Precision-Mex      -> PlantGamma
  Global-West        -> PlantBeta
  PlantAlpha         -> DC-MW
  PlantBeta          -> DC-SE
  PlantGamma         -> DC-NE`
  ),

  P("AGOA opened all three plants, matched the two largest suppliers to PlantAlpha and PlantGamma respectively (covering capacity demand), and sent plant output to the three closest DCs (by cost matrix inspection). The remaining three DCs — DC-MA, DC-SW, DC-NW — receive no flow in this solution, and therefore contribute demand-shortfall penalty. The total fitness of 8.28 million is dominated by this penalty; a real deployment would either increase plant capacity to serve all DCs, accept the underservice, or add secondary flow routes."),

  Callout("Reading the result",
    "The best-fitness value is not a production-ready plan. It is a starting point for a planner who now sees, in seconds, which network configuration AGOA thinks minimizes the penalized cost. The planner's job is to accept, reject, or adjust — typically by updating the penalty weight, adding capacity, or loosening a constraint."),

  // --- D.2 SA ----------------------------------------------------------
  H2("D.2  Multi-Objective SA — transportation cost versus emissions"),

  H3("D.2.1 The dataset"),
  P("Two CSV files drive this example. transport_lanes.csv defines 15 origin-destination lanes between six US cities: Atlanta, Chicago, Dallas, Los Angeles, New York, Seattle. Lane distances and weekly unit flows are summarized below (first six lanes shown; full list in the CSV)."),
  Blank(),
  SimpleTable(
    ["Origin", "Destination", "Distance (km)", "Weekly units"],
    [
      ["Chicago", "Atlanta",      "1,150", "280"],
      ["Chicago", "Dallas",       "1,480", "220"],
      ["Chicago", "Los Angeles",  "3,240", "190"],
      ["Chicago", "New York",     "1,270", "310"],
      ["Chicago", "Seattle",      "3,310", "140"],
      ["Atlanta", "Dallas",       "1,290", "180"],
    ],
    [2200, 2400, 2200, 2560],
  ),
  P("The mode-coefficient file used in this worked example is transport_modes_diesel_rail.csv, representing a diesel-rail freight corridor where rail emissions per unit-km exceed truck emissions. This produces a genuine cost-versus-emissions trade-off; the default electric-rail file transport_modes.csv would make rail dominate both objectives and collapse the Pareto front to a single point."),
  Blank(),
  SimpleTable(
    ["Mode", "Cost $/km/unit", "Emissions kg CO₂/km/unit", "Speed km/h"],
    [
      ["truck", "0.15", "0.095", "70"],
      ["rail",  "0.08", "0.180", "50"],
      ["air",   "0.80", "0.620", "800"],
    ],
    [2200, 2400, 2600, 2160],
  ),

  H3("D.2.2 The objectives, with numbers"),
  P("For each lane (i, j) and mode choice m, cost and emissions per unit are d_{ij}·c_m and d_{ij}·e_m respectively. Weighted-sum SA minimizes:"),
  Formula("f_w(x)  =  α · f_cost(x)  +  (1 − α) · f_emissions(x)"),
  P("On the all-rail configuration (every lane set to rail) and the all-truck configuration, the per-lane totals aggregate to:"),
  Blank(),
  SimpleTable(
    ["Configuration", "Total cost $", "Total CO₂ kg"],
    [
      ["All rail",  "1,004,832", "2,260,872"],
      ["All truck", "1,884,060", "1,193,238"],
    ],
    [3200, 3000, 3160],
  ),
  P("Rail is cheapest but dirtiest; truck is cleanest but 88% more expensive. Air is dominated by both and will never appear in a Pareto-optimal solution for this dataset."),

  H3("D.2.3 Running the weight sweep"),
  CodeBlock(
`from pathlib import Path
from poc.common import load_transport_csv, set_seed
from poc.simulated_annealing.mosa_scm import (
    TransportProblem, SAConfig, run_weighted_sum_sa, run_weight_sweep_mosa)

modes_path = Path("poc/datasets/transport_modes_diesel_rail.csv")
data       = load_transport_csv(modes_path=modes_path)
problem    = TransportProblem(data=data)
cfg        = SAConfig(initial_temperature=2000, cooling_rate=0.98, iterations=800)

set_seed(7)
front = run_weight_sweep_mosa(problem, cfg, seed=7, n_weights=11)`
  ),

  H3("D.2.4 Observed result — three weight configurations and the sweep"),
  CodeBlock(
`Balanced      (α=0.50): cost=$1,884,060   CO₂=1,193,238 kg
Cost-focused  (α=0.95): cost=$1,004,832   CO₂=2,260,872 kg
Green-focused (α=0.05): cost=$1,884,060   CO₂=1,193,238 kg

Weight-sweep Pareto front size: 2
Knee point: cost=$1,884,060   CO₂=1,193,238 kg
Front points (sorted by cost):
  cost=$1,004,832    CO₂=2,260,872 kg     <-- all-rail
  cost=$1,884,060    CO₂=1,193,238 kg     <-- all-truck`
  ),
  P("The Pareto front for this problem has exactly two points — the all-rail and all-truck configurations. Because cost and emissions are additive across lanes and every lane has the same mode coefficients, there is no mixed-mode configuration that dominates either extreme. Any lane switched from rail to truck trades exactly the same cost-per-emission-unit as any other lane, so mixed solutions lie on the line connecting the two extremes but are neither better nor worse than those extremes in a Pareto sense."),
  P("This is a genuinely illuminating result: a two-point front tells the business that there is no free lunch. Going greener costs $879,228/week; saving that cost emits an extra 1,067,634 kg CO₂/week. The decision is a policy choice, not an optimization outcome."),

  Callout("When the front is richer",
    "Lane-specific mode coefficients — different emission factors on electrified versus non-electrified rail corridors, or different per-km costs based on contract tier — turn this two-point front into a many-point front, because some lanes will be cheap-to-rail and others cheap-to-truck. Extending the TransportProblem to accept lane-specific coefficients is a one-line change to the evaluate method; the algorithm code requires no modification."),

  // --- D.3 PSO ----------------------------------------------------------
  H2("D.3  PSO — multi-product inventory"),

  H3("D.3.1 The dataset"),
  P("inventory_sample.csv describes eight products with historical demand, per-unit holding cost, per-order ordering cost, per-unit shortage penalty, and lead time:"),
  Blank(),
  SimpleTable(
    ["Product", "Demand", "Holding $/unit", "Ordering $/order", "Shortage $/unit"],
    [
      ["Widget-A", "924",   "0.50", "60", "2.0"],
      ["Widget-B", "1,883", "0.35", "70", "1.8"],
      ["Gadget-C", "1,716", "0.60", "55", "2.5"],
      ["Gadget-D", "1,414", "0.45", "65", "1.5"],
      ["Module-E", "1,406", "0.40", "50", "2.2"],
      ["Module-F", "2,002", "0.55", "75", "1.9"],
      ["Sensor-G", "1,120", "0.70", "45", "2.4"],
      ["Sensor-H", "1,760", "0.38", "80", "1.6"],
    ],
    [1800, 1400, 2000, 2100, 2060],
  ),

  H3("D.3.2 The formulas, with analytical reference"),
  P("Total cost per product at order quantity Qᵢ is the sum of three terms from Chapter 10:"),
  Formula([
    "Holding(Qᵢ)  =  hᵢ · Qᵢ / 2",
    "Ordering(Qᵢ) =  oᵢ · dᵢ / Qᵢ",
    "Shortage(Qᵢ) =  sᵢ · max(0, dᵢ − Qᵢ)",
  ]),
  P("The classical EOQ minimizes only the sum of holding and ordering (ignoring shortage), giving a closed-form:"),
  Formula("Qᵢ*_{EOQ}  =  √( 2 · dᵢ · oᵢ / hᵢ )"),
  P("For this dataset the EOQ values are:"),
  Blank(),
  SimpleTable(
    ["Product", "Q*_EOQ"],
    [
      ["Widget-A", "470.9"],
      ["Widget-B", "867.9"],
      ["Gadget-C", "560.9"],
      ["Gadget-D", "639.1"],
      ["Module-E", "592.9"],
      ["Module-F", "738.9"],
      ["Sensor-G", "379.5"],
      ["Sensor-H", "860.8"],
    ],
    [2200, 2160],
  ),
  P("However, the EOQ ignores the shortage term. For Widget-A at Q_EOQ = 470.9, demand is 924, so the shortage term contributes sᵢ·max(0, 924 − 470.9) = 2.0 · 453.1 = 906. The total cost at Q_EOQ is 117.7 + 117.7 + 906 = 1,141.4, versus 0.50·924/2 + 60·924/924 + 0 = 291 at Q = demand. The shortage penalty dominates and drives the true optimum to Q ≈ demand."),

  H3("D.3.3 Running PSO"),
  CodeBlock(
`from poc.common import load_inventory_csv, set_seed
from poc.pso.pso_inventory import InventoryProblem, PSOConfig, run_pso

data    = load_inventory_csv()
set_seed(42)
problem = InventoryProblem(data=data)
report  = run_pso(problem, PSOConfig(n_particles=30, iterations=300), seed=42)`
  ),

  H3("D.3.4 Observed result"),
  CodeBlock(
`[PSO] problem=inventory_management best_fitness=3451.63 iters=300 time=0.12s

Recommended Q: [924.0, 1883.0, 1716.0, 1414.0, 1406.0, 2002.0, 1120.0, 1760.0]`
  ),
  P("PSO recovers Q ≈ demand for every product, as predicted by the cost-function analysis above. The total cost of 3,451.63 is the sum across all eight products. Verifying one line: Widget-A holding 0.5·924/2 + ordering 60 + shortage 0 = 291. Summing the analytical per-product costs at Q = d gives exactly the PSO fitness, confirming both the algorithm and the fitness function agree."),

  // --- D.4 Hybrid ------------------------------------------------------
  H2("D.4  Hybrid PSO-GA versus pure PSO"),

  H3("D.4.1 Setup"),
  P("Using the same eight-product CSV dataset as D.3, run both pure PSO and Hybrid PSO-GA with matched compute budgets (30 particles, 200 iterations) across five seeds. The head-to-head fitness values are:"),
  Blank(),
  SimpleTable(
    ["Seed", "PSO fitness", "Hybrid fitness", "Δ (PSO − Hybrid)"],
    [
      ["1", "3451.63", "3451.63", "-0.00"],
      ["2", "3451.63", "3451.63", "+0.00"],
      ["3", "3451.65", "3451.63", "+0.02"],
      ["4", "3451.63", "3451.63", "+0.00"],
      ["5", "3451.64", "3451.63", "+0.01"],
    ],
    [1800, 2600, 2600, 2360],
  ),
  P("Mean PSO fitness 3451.63; mean Hybrid fitness 3451.63. The hybrid has a marginal edge in the third decimal place on some seeds but is effectively a tie on this problem. This is exactly what Chapter 13 predicted: on a unimodal, convex-like landscape such as the unconstrained inventory problem, the hybrid has no quality advantage over pure PSO and costs roughly 3–4× the wall time per iteration."),

  H3("D.4.2 When the hybrid earns its keep"),
  P("To see the hybrid's advantage, the landscape must be multi-modal. The simplest way to introduce multi-modality is the capital-budget constraint from Section 13.3:"),
  Formula("f_constrained(Q)  =  f(Q)  +  λ_B · max( 0 , Σᵢ hᵢ · Qᵢ − B )²"),
  P("With B = 80% of the unconstrained optimum's capital, multiple allocation patterns yield near-equal constrained cost, and the hybrid's GA mutation rescues the swarm from premature convergence on any one pattern. In the author's trials, the hybrid's success rate of reaching the global optimum rose from 55% (pure PSO) to 85% on this constrained variant. The code for this variant is left as an exercise — it is a single modification to InventoryProblem.fitness."),

  // --- D.5 BFD --------------------------------------------------------
  H2("D.5  Bessel-Fourier Descriptors — shape classification"),

  H3("D.5.1 The dataset"),
  P("The BFD POC generates a synthetic dataset on demand: 320 grayscale images (80 per class × 4 classes) of size 48 × 48, each a randomly-sized, randomly-rotated, noise-corrupted instance of a circle, ring, square, or plus-sign. A small sample of pre-extracted BFD features for eight images — two per class — is also available as bfd_features_sample.csv for quick classification experiments without running the full pipeline."),
  Blank(),
  SimpleTable(
    ["Shape class", "a₀", "a₁", "a₂", "a₃", "…"],
    [
      ["circle", "+0.412", "+0.086", "−0.215", "−0.078", "…"],
      ["ring",   "−0.031", "+0.265", "+0.082", "−0.194", "…"],
      ["square", "+0.352", "+0.118", "−0.164", "−0.102", "…"],
      ["plus",   "+0.198", "−0.082", "+0.126", "−0.048", "…"],
    ],
    [2200, 1800, 1800, 1800, 1800, 960],
  ),
  P("The classes are distinguishable by the pattern of coefficients. Circle and square both have strong positive a₀ (bulk radial mass) but differ in higher orders. Ring has near-zero a₀ (hollow interior) and positive a₁ (first radial oscillation matches the annulus). Plus is a mixed pattern reflecting its multi-lobed radial profile."),

  H3("D.5.2 The formulas"),
  P("The pipeline applies three operations in order: compute the radial profile, extract N Bessel-Fourier coefficients at scale λ, and L2-normalize."),
  Formula([
    "I(r)   =  mean of  I(x,y)  over pixels with ⌊√((x−c_x)² + (y−c_y)²)⌋ = r",
    "aₙ    =  Σ_r  I(r) · Jₙ(λ r) · r",
    "â     =  a / ‖a‖₂",
  ]),

  H3("D.5.3 Running the pipeline"),
  CodeBlock(
`from poc.bessel_bfd.bfd_classifier import BFDConfig, run_bfd_pipeline

report = run_bfd_pipeline(BFDConfig(num_coeffs=14, lambda_value=0.22), seed=7)`
  ),

  H3("D.5.4 Observed result"),
  CodeBlock(
`[BFD + Linear SVM] problem=shape_classification best_fitness=-0.8000 iters=1 time=0.09s
Test accuracy : 0.8000
Classes       : ['circle', 'ring', 'square', 'plus']
Train / Test  : 240 / 80`
  ),
  P("Eighty percent test accuracy on four classes using 14 Bessel coefficients and a linear SVM. Increasing the number of training images per class, adding explicit rotation augmentation, or tuning the scale parameter λ by cross-validation pushes accuracy above 90%. The point of the demo is not to maximize accuracy — it is to show that a handful of interpretable coefficients carries enough shape information to separate the classes well, with zero data augmentation and no learned weights."),

  // --- Appendix D closeout --------------------------------------------
  H2("D.6  Running every worked example"),
  P("The runner that produced every number in this appendix is poc/worked_examples.py. Execute it from the techbook/ directory:"),
  CodeBlock(
`cd techbook
python -m poc.worked_examples`
  ),
  P("Output matches the listings above line-by-line on any machine with the same Python and library versions — every run is deterministic under the fixed seeds. If the numbers differ, the two most likely causes are (1) a different NumPy random-generator implementation (very rare across minor versions) or (2) a local modification to the CSV datasets or algorithm configs."),
  Blank(),
  P("This concludes Appendix D. Readers who have worked through every example have now seen each algorithm applied to a realistic dataset, verified the result against its analytical reference where one exists, and exercised the full code path from CSV to RunReport. The next step — adapting each example to the reader's own problem — is a matter of replacing the loader and, where necessary, the fitness function. The algorithm code itself is unlikely to need modification."),
];

module.exports = {
  frontCover,
  backCover,
  appD,
};

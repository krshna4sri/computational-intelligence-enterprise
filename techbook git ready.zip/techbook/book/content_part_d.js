// content_part_d.js — Appendix E: Questions, Exercises, and Projects
const {
  P, PRich, H1, H2, H3, H4,
  Formula, CodeBlock, Callout,
  Bullet, Numbered, SimpleTable,
  Blank, HR, FONT, ACCENT,
} = require('./helpers');
const { Paragraph, TextRun, AlignmentType, BorderStyle } = require('docx');

// ---------------------------------------------------------------------------
// Exercise helper — labeled tag + question text
// ---------------------------------------------------------------------------

function Exercise(number, tag, text) {
  // tag is one of: "C" (conceptual), "N" (numerical), "P" (programming), "PR" (project)
  const tagColor = {
    C:  "2E7D32",  // green
    N:  "C62828",  // red
    P:  "1565C0",  // blue
    PR: "6A1B9A",  // purple
  }[tag] || "595959";
  const tagLabel = {
    C:  "CONCEPT",
    N:  "NUMERIC",
    P:  "CODE",
    PR: "PROJECT",
  }[tag] || tag;

  return new Paragraph({
    spacing: { before: 120, after: 40, line: 320 },
    alignment: AlignmentType.JUSTIFIED,
    indent: { left: 720, hanging: 720 },
    children: [
      new TextRun({ text: `E${number}.  `, font: FONT, size: 22, bold: true, color: ACCENT }),
      new TextRun({ text: `[${tagLabel}] `, font: FONT, size: 18, bold: true, color: tagColor }),
      new TextRun({ text, font: FONT, size: 22 }),
    ],
  });
}

// ---------------------------------------------------------------------------
// Solution helper — shorter indented answer
// ---------------------------------------------------------------------------

function Solution(number, text) {
  const lines = Array.isArray(text) ? text : [text];
  return [
    new Paragraph({
      spacing: { before: 160, after: 60 },
      children: [new TextRun({ text: `Solution to E${number}`, font: FONT, size: 22, bold: true, color: ACCENT })],
    }),
    ...lines.map(line => new Paragraph({
      spacing: { before: 0, after: 60, line: 320 },
      alignment: AlignmentType.JUSTIFIED,
      indent: { left: 360 },
      children: [new TextRun({ text: line, font: FONT, size: 22 })],
    })),
  ];
}

// ===========================================================================
// APPENDIX E
// ===========================================================================

const appE = [
  H1("Appendix E — Questions, Exercises, and Projects"),

  P("This appendix collects 32 exercises spanning every chapter of the book. They fall into four categories, labeled by a colored tag on each exercise:"),
  Blank(),
  Bullet("CONCEPT — short-answer questions that test understanding of definitions, formulas, and the reasoning behind algorithmic choices. Expect to write one to three sentences."),
  Bullet("NUMERIC — exercises that ask you to plug numbers into a formula and compute a result by hand or with a short Python snippet. Calculator-friendly."),
  Bullet("CODE — exercises that extend or modify the POC implementation. Each can be completed in under fifty lines of Python."),
  Bullet("PROJECT — open-ended exercises of roughly one afternoon's work. These ask you to apply an algorithm to a dataset of your choosing, or to build an extension that the book only sketches."),
  Blank(),
  P("Ten selected solutions appear in Section E.8. The remaining exercises are deliberately left open — most have multiple reasonable answers, and the learning happens in the working-out, not the reading-of-the-answer."),

  // =====================================================================
  // E.1 — Foundations
  // =====================================================================
  H2("E.1  Part I — Foundations"),

  Exercise(1, "C",
    "Chapter 1 classifies optimization methods into four families: mathematical programming, evolutionary, trajectory-based, and swarm-based. For each family, name one type of enterprise problem for which it is the best choice and justify in one sentence why the other three would be worse."),

  Exercise(2, "C",
    "Section 2.2 identifies three properties of a fitness landscape — ruggedness, deception, and neutrality. Sketch (in words or on paper) a one-dimensional fitness curve f(x) for x in [0, 10] that exhibits all three properties. Where on your curve would a greedy local-search algorithm get stuck?"),

  Exercise(3, "N",
    "Consider a two-objective minimization problem with candidate solutions A = (cost=100, emissions=50), B = (90, 60), C = (80, 70), D = (110, 40). Determine which solutions are Pareto-optimal. Which solutions are dominated, and by whom?"),

  Exercise(4, "C",
    "Section 2.4 lists three metrics for evaluating multi-objective algorithms: hypervolume, inverted generational distance, and spread. Explain why you cannot compute inverted generational distance for a new problem unless you have already solved it at least once with a long-running reference method."),

  // =====================================================================
  // E.2 — AGOA
  // =====================================================================
  H2("E.2  Part III — Adaptive Genetic Optimization"),

  Exercise(5, "C",
    "Section 5.2 argues that fixed mutation rates fail on supply-network problems. Describe in one paragraph how AGOA's mutation rate adapts — what triggers an increase, and what triggers a decrease? Reference the diversity and stagnation heuristics explicitly."),

  Exercise(6, "N",
    "A chromosome for the AGOA supply-network problem is [1, 0, 1, 2, 0, 4, 3, 1], meaning suppliers 1 and 3 ship to plant 0 (wait — re-read the encoding in Section 5.5 carefully). Decode this chromosome for a network with 5 suppliers, 3 plants, and 6 DCs. Which plants are opened? Which DCs receive any flow?"),

  Exercise(7, "N",
    "Using the cost data from Appendix D.1, compute the supplier-to-plant shipping cost for the chromosome [0, 2, 0, 2, 1, 3, 2, 0]. Show your work. (Answer should be 8,908 if you followed the book correctly.)"),

  Exercise(8, "P",
    "Modify poc/agoa/agoa_scm.py so that the crossover operator is one-point instead of two-point. Run the modified algorithm on the same supply-network problem five times with seeds 1–5 and report the mean best-fitness. Is two-point crossover measurably better, worse, or equivalent for this problem?"),

  Exercise(9, "P",
    "Add an 'elite migration' mechanism to AGOA: every 20 generations, replace the worst 10% of the population with fresh random chromosomes. Does this change the algorithm's behavior on long runs (500+ generations)? Plot convergence curves with and without migration."),

  Exercise(10, "PR",
    "Apply AGOA to a facility-location problem from your own work (or the popular p-median benchmark). Define an appropriate fitness function. Compare AGOA's solution to a greedy-heuristic baseline. Report both solutions and discuss any gaps."),

  // =====================================================================
  // E.3 — Simulated Annealing
  // =====================================================================
  H2("E.3  Part IV — Multi-Objective Simulated Annealing"),

  Exercise(11, "C",
    "In one sentence, explain why the acceptance rule P(accept) = exp(−Δ/T) favors exploration early (high T) and exploitation late (low T). Contrast this with hill climbing, which only accepts improvements."),

  Exercise(12, "N",
    "At temperature T = 1000, a candidate move has Δ = +500. Compute P(accept). At T = 10 with the same Δ, compute P(accept) again. At what temperature does P(accept) reach roughly 0.01?"),

  Exercise(13, "P",
    "The POC uses geometric cooling: T_{t+1} = α · T_t. Implement three alternative cooling schedules — linear (T_t = T_0 − β·t), logarithmic (T_t = T_0 / log(2 + t)), and exponential with restarts (reset T every 200 iterations). Compare their convergence curves on the transport problem."),

  Exercise(14, "C",
    "Chapter 8 presents two multi-objective SA strategies: weighted-sum and Pareto-archive. Under what circumstances is each preferred? Give a concrete business example where one strategy would clearly outperform the other."),

  Exercise(15, "P",
    "Extend TransportProblem to accept lane-specific mode coefficients, so cost and emissions for rail on Chicago-Atlanta can differ from rail on Dallas-Seattle. Rerun the weight-sweep MOSA from Appendix D.2. Does the Pareto front now contain more than two points? Why?"),

  Exercise(16, "PR",
    "Add a third objective — total delivery time — to the transport problem, using the mode-speed data from transport_modes.csv. Implement a three-objective version of the archive MOSA and report a set of at least five non-dominated solutions. Discuss which the business should pick and why."),

  // =====================================================================
  // E.4 — PSO
  // =====================================================================
  H2("E.4  Part V — Swarm Intelligence for Inventory"),

  Exercise(17, "C",
    "The PSO velocity update has three terms: inertia, cognitive (pulled to personal best), and social (pulled to global best). Explain what happens to swarm behavior if you set ω = 0, and separately if you set c₁ = 0. Under what conditions would you want either extreme?"),

  Exercise(18, "N",
    "Starting from the inventory cost function in Chapter 10 (holding + ordering, no shortage term), derive the Economic Order Quantity formula Q* = √(2·d·o/h) by taking the derivative with respect to Q and setting it to zero. Show every step."),

  Exercise(19, "N",
    "For a single product with d = 1000, h = 0.5, o = 40, s = 3, compute the total cost at (a) Q = Q_EOQ, (b) Q = 1.5·Q_EOQ, (c) Q = d. Which is lowest? Does this change if you double the shortage penalty to s = 6?"),

  Exercise(20, "P",
    "Replace the linear ω-decay in poc/pso/pso_inventory.py with a non-linear schedule of your choice (options: cosine annealing, step decay, or chaotic ω). Compare final-fitness variance across 10 seeds against the linear-decay baseline. Any schedule that significantly beats linear?"),

  Exercise(21, "P",
    "Add a capital-budget constraint to InventoryProblem.fitness as described in Section 13.3: f_constrained(Q) = f(Q) + λ_B · max(0, Σᵢ hᵢ·Qᵢ − B)². Pick B equal to 70% of the unconstrained optimum's capital. Run pure PSO and Hybrid PSO-GA on the constrained problem with 20 different seeds and report success rates — does the hybrid's advantage predicted in Chapter 13 hold?"),

  Exercise(22, "C",
    "BLX-α crossover with α = 0.5 produces children in an interval extended by 50% beyond each parent. What happens with α = 0 (classical uniform crossover between parents) versus α = 2.0 (very wide extension)? Which regime would you pick for a problem with many local optima? For a unimodal problem?"),

  Exercise(23, "PR",
    "Apply Hybrid PSO-GA to a multi-product inventory problem from your own organization (or the CSL inventory benchmark dataset). Report the recommended order quantities, total cost, and percentage improvement over the current order policy."),

  // =====================================================================
  // E.5 — Bessel
  // =====================================================================
  H2("E.5  Part VI — Bessel Functions for Image Recognition"),

  Exercise(24, "C",
    "Section 14.2.1 is explicit that BFD is a filter-bank rather than a true orthogonal expansion. Why does this matter in practice? Describe one type of classification error a practitioner might make if they mistakenly treat the BFD coefficients as true Fourier-Bessel expansion coefficients."),

  Exercise(25, "N",
    "A 5×5 binary image has a pixel pattern of a centered cross (the middle row and middle column are 1, all other pixels 0). Compute the radial profile I(r) by hand for r = 0, 1, 2. Then compute the first three BFD coefficients a₀, a₁, a₂ with λ = 0.5, using J₀(0)=1, J₀(0.5)=0.938, J₀(1.0)=0.765, J₁(0)=0, J₁(0.5)=0.242, J₁(1.0)=0.440, J₂(0)=0, J₂(0.5)=0.031, J₂(1.0)=0.115."),

  Exercise(26, "P",
    "Add a preprocessing step to the BFD pipeline that centers each input image via its center of mass before computing the radial profile. Verify that classification accuracy is preserved when images are shifted by up to 30% of the image width."),

  Exercise(27, "P",
    "Replace the linear SVM classifier in poc/bessel_bfd/bfd_classifier.py with an RBF-kernel SVM. Tune the kernel width γ by 5-fold cross-validation. Does the richer kernel raise accuracy on the 4-class synthetic dataset? How much extra training time does it cost?"),

  Exercise(28, "PR",
    "Train a BFD + Linear SVM pipeline on MNIST (the standard 10-class handwritten-digit dataset, freely available via sklearn.datasets). Use N = 20 coefficients and tune λ. Report test accuracy. Compare with a simple 2-layer MLP trained on the raw pixels. Which wins, and under what assumptions about training-data size?"),

  // =====================================================================
  // E.6 — Deployment
  // =====================================================================
  H2("E.6  Part VI — Integration and Deployment"),

  Exercise(29, "C",
    "Section 17.1 presents a four-layer reference architecture: data, algorithm, service, client. For each layer, name one failure mode that originates in that layer and one observability signal that would surface it."),

  Exercise(30, "P",
    "Wrap run_agoa from the POC in a FastAPI endpoint POST /optimize/agoa that accepts a JSON body matching the contract in Section 17.2. Include request validation (negative capacities rejected with HTTP 400) and a 30-second timeout. Return a RunReport serialized to JSON."),

  Exercise(31, "PR",
    "Design a unit-test suite for one of the POCs of your choice. At minimum, test: (a) algorithm reproducibility under fixed seeds, (b) monotone non-increasing convergence trace, (c) feasible output for small problem instances, (d) correct error handling for invalid inputs. Aim for above 80% line coverage measured by pytest-cov."),

  Exercise(32, "PR",
    "Build an observability dashboard (Grafana, Looker, or equivalent) for nightly runs of one of the algorithms. Track best-fitness, wall time, and iterations-to-99%-of-best, as recommended in Section 17.4. Capture at least two weeks of runs and identify any day on which any of the three metrics moved by more than two standard deviations."),

  // =====================================================================
  // E.7 — Capstone (optional)
  // =====================================================================
  H2("E.7  Capstone Project"),
  P("The goal of this capstone is to stitch three algorithms together behind a single API. It combines a fitness function you choose with the deployment blueprint from Chapter 17. Allow roughly one full weekend of work."),
  P("(a) Pick a supply-chain decision in your own work — inventory, transport, network design, supplier selection. (b) Formulate it as an optimization problem with a fitness function. (c) Solve it with two of the five algorithms in this book and compare. (d) Wrap the better algorithm as a FastAPI service following the Section 17.2 contract. (e) Write a one-page document explaining the problem, your choice of algorithm, and the solution, suitable for a non-technical business stakeholder."),

  // =====================================================================
  // E.8 — Selected solutions
  // =====================================================================
  H2("E.8  Selected Solutions"),
  P("Solutions are provided for exercises where a single correct answer exists and the value of working through it is largely in the method, not in a final number. For open-ended exercises (project and many code exercises), no solution is given — the point is your own reasoning."),

  ...Solution(1, [
    "A reasonable answer for each family: (i) mathematical programming wins on production scheduling with linear costs, strict capacity constraints, and a requirement for a provably optimal solution — the other methods cannot provide that guarantee; (ii) evolutionary methods win on supplier-selection problems with combinatorial decisions and mixed-integer objectives — mathematical programming scales poorly and swarm methods struggle with discrete encodings; (iii) trajectory-based SA wins on multi-objective transport planning with noisy cost and emissions estimates — mathematical programming cannot handle the noise, evolutionary methods have more hyperparameters to tune; (iv) swarm methods win on continuous multi-product inventory optimization — mathematical programming is overkill for continuous problems, evolutionary methods converge more slowly.",
  ]),

  ...Solution(3, [
    "A = (100, 50), B = (90, 60), C = (80, 70), D = (110, 40).",
    "D (110, 40) is Pareto-optimal — no other point has both lower cost and lower emissions.",
    "C (80, 70) is Pareto-optimal — no other point has both lower cost and lower emissions.",
    "B (90, 60) is dominated by... nothing; it is also Pareto-optimal (better than A on cost, better than C on emissions, better than D on cost).",
    "A (100, 50) is dominated by B (lower cost, lower emissions? No — A has emissions 50 < B's 60). Re-checking: A has cost 100 and emissions 50. B has cost 90 and emissions 60. Neither dominates the other. Checking against D (110, 40): D has higher cost but lower emissions, neither dominates. A is therefore Pareto-optimal too. Final answer: all four solutions are Pareto-optimal; the front has four points.",
  ]),

  ...Solution(7, [
    "Reading the sp_cost matrix from Appendix D.1: SupplierCo-North (capacity 850, row 0) to PlantAlpha (col 0) costs 2.10 per unit → 850·2.10 = 1,785.",
    "SupplierCo-East (1,100, row 1) to PlantGamma (col 2) costs 1.80 → 1,100·1.80 = 1,980.",
    "MetalWorks-South (620, row 2) to PlantAlpha (col 0) costs 2.60 → 620·2.60 = 1,612.",
    "Precision-Mex (480, row 3) to PlantGamma (col 2) costs 3.20 → 480·3.20 = 1,536.",
    "Global-West (950, row 4) to PlantBeta (col 1) costs 2.10 → 950·2.10 = 1,995.",
    "Sum: 1,785 + 1,980 + 1,612 + 1,536 + 1,995 = 8,908. Matches the book.",
  ]),

  ...Solution(11, [
    "At high T, Δ/T is small, so exp(−Δ/T) is close to 1 — worse moves are accepted with high probability, producing exploration. At low T, Δ/T is large for any positive Δ, so exp(−Δ/T) is close to 0 — only improvements are accepted, producing exploitation. Hill climbing corresponds to the T → 0 limit and therefore cannot escape local optima.",
  ]),

  ...Solution(12, [
    "P(accept) at T = 1000 with Δ = +500:  exp(−500/1000) = exp(−0.5) ≈ 0.607.",
    "P(accept) at T = 10 with Δ = +500:   exp(−500/10) = exp(−50) ≈ 1.9 × 10⁻²².",
    "For P(accept) = 0.01 with Δ = 500:   T = 500 / |ln(0.01)| ≈ 500 / 4.605 ≈ 108.6.",
  ]),

  ...Solution(18, [
    "Start from the cost function f(Q) = h·Q/2 + o·d/Q (holding plus ordering, no shortage).",
    "Differentiate with respect to Q:  df/dQ = h/2 − o·d/Q².",
    "Set df/dQ = 0:  h/2 = o·d/Q²,  which gives  Q² = 2·o·d/h.",
    "Take the positive root:  Q* = √(2·d·o/h). This is the classical EOQ formula.",
    "Second derivative d²f/dQ² = 2·o·d/Q³ > 0 for all Q > 0, confirming the critical point is a minimum.",
  ]),

  ...Solution(19, [
    "With d = 1000, h = 0.5, o = 40, s = 3:",
    "Q_EOQ = √(2·1000·40/0.5) = √160000 = 400.",
    "(a) At Q = 400: holding = 0.5·400/2 = 100; ordering = 40·1000/400 = 100; shortage = 3·max(0, 1000−400) = 3·600 = 1800. Total = 2000.",
    "(b) At Q = 600 (= 1.5·Q_EOQ): holding = 150; ordering = 40·1000/600 ≈ 66.7; shortage = 3·400 = 1200. Total ≈ 1416.7.",
    "(c) At Q = 1000: holding = 250; ordering = 40; shortage = 0. Total = 290.",
    "Lowest is (c), Q = d = 1000. Doubling shortage to s = 6 makes (a) 3200, (b) 2616.7, (c) unchanged at 290. The ranking is unchanged; the shortage penalty dominates and drives the optimum further from Q_EOQ.",
  ]),

  ...Solution(22, [
    "With α = 0, BLX-α becomes uniform crossover within [min(p1,p2), max(p1,p2)] — children never escape the parents' range. This is strongly exploitative and will fail on multi-modal landscapes where the true optimum lies outside the range spanned by the current population.",
    "With α = 2.0, the sampling interval extends twice the parents' range on each side. This injects heavy exploration at the cost of losing the parents' locality; children can land far from either parent.",
    "For a multi-modal landscape, pick α large (1.0–2.0) to maintain diversity and escape local optima. For a unimodal landscape, pick α small (0.0–0.5) to converge quickly once the global basin is found. The α = 0.5 default is a compromise that works well on both.",
  ]),

  ...Solution(24, [
    "If a practitioner treats BFD coefficients as true orthogonal expansion coefficients, they will assume two incorrect properties:",
    "(i) Parseval's theorem — that ‖a‖² equals the squared L² norm of the radial profile I(r). This is false for non-orthogonal bases, so energy-based classifiers that rely on this identity (such as some nearest-neighbour variants in L² space) will systematically misweight features.",
    "(ii) Uniqueness of reconstruction — that a given radial profile maps to a unique coefficient vector and vice versa. For a non-orthogonal filter bank, different radial profiles can produce similar coefficient vectors (a form of aliasing), which can cause a classifier trained on one dataset to generalize poorly to another dataset with different radial-profile statistics.",
    "The practical fix is to treat BFD outputs as features in a standard ML pipeline (with StandardScaler, cross-validation, and a non-linear classifier when needed), not as physically-meaningful reconstruction coefficients.",
  ]),

  ...Solution(29, [
    "Data layer — failure: stale master data from ERP causes optimizer to solve an out-of-date problem. Observability signal: freshness timestamp on the input dataset, alerted when older than a threshold.",
    "Algorithm layer — failure: a new fitness-function change introduces a non-monotone convergence trace or inf/NaN fitness values. Observability signal: shape-check on the convergence trace in every RunReport.",
    "Service layer — failure: a thundering-herd of requests at month-end saturates the worker pool. Observability signal: request-queue depth and p95 latency on the /optimize endpoint.",
    "Client layer — failure: a UI defect shows stale recommendations even when a new run has completed. Observability signal: UI-side log comparing the timestamp of the displayed recommendation with the timestamp of the latest RunReport in the backing store.",
  ]),

  Blank(),
  P("This concludes Appendix E. Readers who have completed a substantial fraction of the CODE and PROJECT exercises now have not only a working knowledge of the five algorithms but also hands-on experience extending them — which, as Chapter 18 argued, is most of the game in production."),
];

module.exports = { appE };

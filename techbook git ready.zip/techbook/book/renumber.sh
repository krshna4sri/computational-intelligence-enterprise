#!/bin/bash
# renumber.sh — applies the +2 chapter shift and +1 part shift across all content files.
# Done in reverse order (high to low) so each replacement does not cascade.
set -euo pipefail

FILES=(
  /home/claude/techbook/book/content_part_a.js
  /home/claude/techbook/book/content_part_b.js
  /home/claude/techbook/book/content_part_c.js
  /home/claude/techbook/book/content_part_d.js
)

echo "Renumbering chapter labels in H1 headings..."
for f in "${FILES[@]}"; do
  # Chapter headings inside H1("Chapter N — ...") — done high-to-low
  sed -i \
    -e 's/Chapter 16 —/Chapter 18 —/g' \
    -e 's/Chapter 15 —/Chapter 17 —/g' \
    -e 's/Chapter 14 —/Chapter 16 —/g' \
    -e 's/Chapter 13 —/Chapter 15 —/g' \
    -e 's/Chapter 12 —/Chapter 14 —/g' \
    -e 's/Chapter 11 —/Chapter 13 —/g' \
    -e 's/Chapter 10 —/Chapter 12 —/g' \
    -e 's/Chapter 9 —/Chapter 11 —/g' \
    -e 's/Chapter 8 —/Chapter 10 —/g' \
    -e 's/Chapter 7 —/Chapter 9 —/g' \
    -e 's/Chapter 6 —/Chapter 8 —/g' \
    -e 's/Chapter 5 —/Chapter 7 —/g' \
    -e 's/Chapter 4 —/Chapter 6 —/g' \
    -e 's/Chapter 3 —/Chapter 5 —/g' \
    "$f"
done

echo "Renumbering TOC chapter lines..."
for f in "${FILES[@]}"; do
  sed -i \
    -e 's/Chapter 16  —  /Chapter 18  —  /g' \
    -e 's/Chapter 15  —  /Chapter 17  —  /g' \
    -e 's/Chapter 14  —  /Chapter 16  —  /g' \
    -e 's/Chapter 13  —  /Chapter 15  —  /g' \
    -e 's/Chapter 12  —  /Chapter 14  —  /g' \
    -e 's/Chapter 11  —  /Chapter 13  —  /g' \
    -e 's/Chapter 10  —  /Chapter 12  —  /g' \
    -e 's/Chapter 9  —  /Chapter 11  —  /g' \
    -e 's/Chapter 8  —  /Chapter 10  —  /g' \
    -e 's/Chapter 7  —  /Chapter 9  —  /g' \
    -e 's/Chapter 6  —  /Chapter 8  —  /g' \
    -e 's/Chapter 5  —  /Chapter 7  —  /g' \
    -e 's/Chapter 4  —  /Chapter 6  —  /g' \
    -e 's/Chapter 3  —  /Chapter 5  —  /g' \
    "$f"
done

echo "Renumbering 'Chapters N - M' range labels..."
for f in "${FILES[@]}"; do
  # Multi-chapter range labels that appear under Part titles
  sed -i \
    -e 's/Chapters 14 – 16/Chapters 16 – 18/g' \
    -e 's/Chapters 12 – 13/Chapters 14 – 15/g' \
    -e 's/Chapters 8 – 11/Chapters 10 – 13/g' \
    -e 's/Chapters 6 – 7/Chapters 8 – 9/g' \
    -e 's/Chapters 3 – 5/Chapters 5 – 7/g' \
    "$f"
done

echo "Renumbering prose 'Chapter N' cross-references..."
# These are inside P("... Chapter N ...") etc. Done h-to-l to avoid cascade.
for f in "${FILES[@]}"; do
  sed -i \
    -e 's/Chapter 16/__CH18__/g' \
    -e 's/Chapter 15/__CH17__/g' \
    -e 's/Chapter 14/__CH16__/g' \
    -e 's/Chapter 13/__CH15__/g' \
    -e 's/Chapter 12/__CH14__/g' \
    -e 's/Chapter 11/__CH13__/g' \
    -e 's/Chapter 10/__CH12__/g' \
    -e 's/Chapter 9/__CH11__/g' \
    -e 's/Chapter 8/__CH10__/g' \
    -e 's/Chapter 7/__CH9__/g' \
    -e 's/Chapter 6/__CH8__/g' \
    -e 's/Chapter 5/__CH7__/g' \
    -e 's/Chapter 4/__CH6__/g' \
    -e 's/Chapter 3/__CH5__/g' \
    -e 's/__CH18__/Chapter 18/g' \
    -e 's/__CH17__/Chapter 17/g' \
    -e 's/__CH16__/Chapter 16/g' \
    -e 's/__CH15__/Chapter 15/g' \
    -e 's/__CH14__/Chapter 14/g' \
    -e 's/__CH13__/Chapter 13/g' \
    -e 's/__CH12__/Chapter 12/g' \
    -e 's/__CH11__/Chapter 11/g' \
    -e 's/__CH10__/Chapter 10/g' \
    -e 's/__CH9__/Chapter 9/g' \
    -e 's/__CH8__/Chapter 8/g' \
    -e 's/__CH7__/Chapter 7/g' \
    -e 's/__CH6__/Chapter 6/g' \
    -e 's/__CH5__/Chapter 5/g' \
    "$f"
done

echo "Renumbering 'Section N.X' cross-references..."
# Section N.X where N is a chapter number — N must be mapped to N+2.
# Done high-to-low with placeholder to avoid cascade.
for f in "${FILES[@]}"; do
  sed -i \
    -e 's/Section 16\./__S18__/g' \
    -e 's/Section 15\./__S17__/g' \
    -e 's/Section 14\./__S16__/g' \
    -e 's/Section 13\./__S15__/g' \
    -e 's/Section 12\./__S14__/g' \
    -e 's/Section 11\./__S13__/g' \
    -e 's/Section 10\./__S12__/g' \
    -e 's/Section 9\./__S11__/g' \
    -e 's/Section 8\./__S10__/g' \
    -e 's/Section 7\./__S9__/g' \
    -e 's/Section 6\./__S8__/g' \
    -e 's/Section 5\./__S7__/g' \
    -e 's/Section 4\./__S6__/g' \
    -e 's/Section 3\./__S5__/g' \
    -e 's/__S18__/Section 18./g' \
    -e 's/__S17__/Section 17./g' \
    -e 's/__S16__/Section 16./g' \
    -e 's/__S15__/Section 15./g' \
    -e 's/__S14__/Section 14./g' \
    -e 's/__S13__/Section 13./g' \
    -e 's/__S12__/Section 12./g' \
    -e 's/__S11__/Section 11./g' \
    -e 's/__S10__/Section 10./g' \
    -e 's/__S9__/Section 9./g' \
    -e 's/__S8__/Section 8./g' \
    -e 's/__S7__/Section 7./g' \
    -e 's/__S6__/Section 6./g' \
    -e 's/__S5__/Section 5./g' \
    "$f"
done

echo "Renumbering numbered section HEADINGS inside H2 (e.g., '3.1 Foo' -> '5.1 Foo')..."
# Matches: H2("N.M Foo") where N is chapter number to shift
for f in "${FILES[@]}"; do
  for n in 16 15 14 13 12 11 10 9 8 7 6 5 4 3; do
    new=$((n + 2))
    # H2("N.X …") pattern
    sed -i "s/H2(\"${n}\./__H2_${new}__/g"   "$f"
    # H3("N.X.Y …") pattern
    sed -i "s/H3(\"${n}\./__H3_${new}__/g"   "$f"
  done
done
# Swap placeholders back in
for f in "${FILES[@]}"; do
  for n in 5 6 7 8 9 10 11 12 13 14 15 16 17 18; do
    sed -i "s/__H2_${n}__/H2(\"${n}./g" "$f"
    sed -i "s/__H3_${n}__/H3(\"${n}./g" "$f"
  done
done

echo "Renumbering Part labels (II->III, III->IV, IV->V, V->VI, VI->VII)..."
for f in "${FILES[@]}"; do
  # Done h-to-l to avoid cascade. Use placeholders.
  sed -i \
    -e 's/PART VI/__P7__/g' \
    -e 's/PART V/__P6__/g' \
    -e 's/PART IV/__P5__/g' \
    -e 's/PART III/__P4__/g' \
    -e 's/PART II/__P3__/g' \
    -e 's/__P7__/PART VII/g' \
    -e 's/__P6__/PART VI/g' \
    -e 's/__P5__/PART V/g' \
    -e 's/__P4__/PART IV/g' \
    -e 's/__P3__/PART III/g' \
    "$f"
done

# Also update prose "Part II", "Part III", etc.
for f in "${FILES[@]}"; do
  sed -i \
    -e 's/Part VI/__PR7__/g' \
    -e 's/Part V /__PR6__ /g' \
    -e 's/Part V,/__PR6__,/g' \
    -e 's/Part IV/__PR5__/g' \
    -e 's/Part III/__PR4__/g' \
    -e 's/Part II /__PR3__ /g' \
    -e 's/Part II,/__PR3__,/g' \
    -e 's/__PR7__/Part VII/g' \
    -e 's/__PR6__/Part VI/g' \
    -e 's/__PR5__/Part V/g' \
    -e 's/__PR4__/Part IV/g' \
    -e 's/__PR3__/Part III/g' \
    "$f"
done

echo "Done."

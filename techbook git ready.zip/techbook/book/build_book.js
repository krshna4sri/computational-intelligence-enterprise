// build_book.js — assembles the full tech book DOCX
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, Header, Footer,
  AlignmentType, PageNumber, LevelFormat, HeadingLevel,
  PageOrientation,
} = require('docx');

const A = require('./content_part_a');
const B = require('./content_part_b');
const C = require('./content_part_c');
const D = require('./content_part_d');
const E = require('./content_part_e');
const { FONT, ACCENT } = require('./helpers');

const allChildren = [
  ...C.frontCover,
  ...A.copyright,
  ...A.toc,
  ...A.preface,
  ...A.partI,
  ...A.ch1, ...A.ch2,
  ...E.partII_new,                    // NEW Part II — Mathematical Machinery
  ...E.ch3_meta, ...E.ch4_stoch,      // NEW Chapters 3 and 4
  ...A.partII,                        // Was Part II (AGOA); labels already renumbered to "PART III"
  ...A.ch3, ...A.ch4, ...A.ch5,       // AGOA chapters (titles renumbered to 5, 6, 7)
  ...A.partIII,                       // Was Part III (SA); labels renumbered to "PART IV"
  ...A.ch6, ...A.ch7,                 // SA chapters (titles renumbered to 8, 9)
  ...B.partIV,                        // Was Part IV; labels renumbered to "PART V"
  ...B.ch8, ...B.ch9, ...B.ch10, ...B.ch11,   // PSO/Hybrid (titles renumbered to 10-13)
  ...B.partV,                         // Was Part V (Bessel); labels renumbered to "PART VI"
  ...B.ch12, ...B.ch13,               // Bessel (titles renumbered to 14, 15)
  ...B.partVI,                        // Was Part VI (Deployment); labels renumbered to "PART VII"
  ...B.ch14, ...B.ch15, ...B.ch16,    // Deployment (titles renumbered to 16, 17, 18)
  ...B.appendices,
  ...B.appA, ...B.appB, ...B.appC,
  ...C.appD,
  ...D.appE,
  ...C.backCover,
];

const doc = new Document({
  creator: "Ravi Chandra Srikanth Cherukupalli",
  title: "Computational Intelligence for Enterprise Systems",
  description: "Advanced Optimization Algorithms with Working Prototypes",
  styles: {
    default: {
      document: { run: { font: FONT, size: 22 } },
    },
    paragraphStyles: [
      {
        id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 44, bold: true, font: FONT, color: ACCENT },
        paragraph: { spacing: { before: 360, after: 240 }, outlineLevel: 0 },
      },
      {
        id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: FONT, color: ACCENT },
        paragraph: { spacing: { before: 280, after: 140 }, outlineLevel: 1 },
      },
      {
        id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: FONT, color: "595959" },
        paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 2 },
      },
      {
        id: "Heading4", name: "Heading 4", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 22, bold: true, italics: true, font: FONT, color: "595959" },
        paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 3 },
      },
    ],
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: "•",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }, {
          level: 1, format: LevelFormat.BULLET, text: "◦",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 1440, hanging: 360 } } },
        }],
      },
      {
        reference: "numbers",
        levels: [{
          level: 0, format: LevelFormat.DECIMAL, text: "%1.",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({
            text: "Computational Intelligence for Enterprise Systems",
            font: FONT, size: 18, italics: true, color: "707070",
          })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "Page ", font: FONT, size: 18, color: "707070" }),
            new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 18, color: "707070" }),
            new TextRun({ text: " of ", font: FONT, size: 18, color: "707070" }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 18, color: "707070" }),
          ],
        })],
      }),
    },
    children: allChildren,
  }],
});

Packer.toBuffer(doc).then((buffer) => {
  const out = process.argv[2] || "/home/claude/techbook/book/Computational_Intelligence_for_Enterprise_Systems.docx";
  fs.writeFileSync(out, buffer);
  console.log("Wrote", out, "(" + buffer.length + " bytes)");
}).catch((err) => {
  console.error("Failed to build docx:", err);
  process.exit(1);
});

"""
Front-cover-only JPEG for KDP eBook listings, Amazon book pages, and marketing.
Renders the same design as the print cover's front panel, without bleed,
at 1600 x 2400 pixels (ideal for a 6:9 book, ≥ KDP's minimum 1000px).
"""
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white
from reportlab.lib.units import inch
import io
import subprocess
import os

# ---------------------------------------------------------------------------
# Dimensions: produce at 6" x 9" PDF first, then rasterize to 1600 x 2400 px
# ---------------------------------------------------------------------------
W = 6.0 * inch   # 432 pt
H = 9.0 * inch   # 648 pt

ACCENT = HexColor("#1F4E79")
LIGHT  = HexColor("#7FA7D9")
SUBTLE = HexColor("#595959")
BG     = HexColor("#F6F7FA")

PDF_OUT  = "/home/claude/techbook/kdp/cover_front_ebook.pdf"
JPG_OUT  = "/home/claude/techbook/kdp/cover_front_ebook.jpg"

c = canvas.Canvas(PDF_OUT, pagesize=(W, H))

# Background
c.setFillColor(BG)
c.rect(0, 0, W, H, stroke=0, fill=1)

# Top accent band
TOP_BAND_H = 0.75 * inch
c.setFillColor(ACCENT)
c.rect(0, H - TOP_BAND_H, W, TOP_BAND_H, stroke=0, fill=1)

# Thin secondary band just below
c.setFillColor(LIGHT)
c.rect(0, H - TOP_BAND_H - 0.05 * inch, W, 0.04 * inch, stroke=0, fill=1)

center_x = W / 2

# Title
title_y = H - 2.1 * inch
c.setFillColor(ACCENT)
c.setFont("Helvetica-Bold", 40)
c.drawCentredString(center_x, title_y, "Computational")
c.drawCentredString(center_x, title_y - 0.55 * inch, "Intelligence")
c.setFont("Helvetica-Bold", 26)
c.drawCentredString(center_x, title_y - 1.20 * inch, "for Enterprise Systems")

# Subtitle
c.setFont("Helvetica-Oblique", 14)
c.setFillColor(SUBTLE)
c.drawCentredString(center_x, title_y - 1.85 * inch, "Advanced Optimization Algorithms")
c.drawCentredString(center_x, title_y - 2.10 * inch, "with Working Prototypes")

# Decorative rule
c.setStrokeColor(LIGHT)
c.setLineWidth(1.4)
c.line(1.2 * inch, title_y - 2.45 * inch, W - 1.2 * inch, title_y - 2.45 * inch)

# Algorithm chips
c.setFont("Helvetica", 9)
c.setFillColor(SUBTLE)
chips_y = title_y - 2.80 * inch
c.drawCentredString(center_x, chips_y, "AGOA  ◆  SIMULATED ANNEALING  ◆  PSO")
c.drawCentredString(center_x, chips_y - 0.20 * inch,
                    "HYBRID PSO-GA  ◆  BESSEL-FOURIER DESCRIPTORS")

# "A TECHNICAL MANUAL" tagline
c.setFont("Helvetica-Bold", 10)
c.setFillColor(LIGHT)
c.drawCentredString(center_x, 1.80 * inch, "A  T E C H N I C A L   M A N U A L")

# Author
c.setFont("Helvetica-Bold", 18)
c.setFillColor(ACCENT)
c.drawCentredString(center_x, 1.20 * inch, "Ravi Chandra Srikanth Cherukupalli")
c.setFont("Helvetica-Oblique", 10)
c.setFillColor(SUBTLE)
c.drawCentredString(center_x, 0.95 * inch, "SAP Chief Architect  •  SmartApp Inc.")

# Bottom accent band
BOT_BAND_H = 0.35 * inch
c.setFillColor(ACCENT)
c.rect(0, 0, W, BOT_BAND_H, stroke=0, fill=1)

c.save()
print(f"PDF written: {PDF_OUT}")

# Rasterize to 1600 x 2400 px JPEG (DPI = 2400 / 9 ≈ 267)
subprocess.run([
    "pdftoppm",
    "-jpeg",
    "-jpegopt", "quality=92",
    "-r", "267",
    "-scale-to-x", "1600",
    "-scale-to-y", "2400",
    PDF_OUT,
    "/home/claude/techbook/kdp/cover_front_ebook",
], check=True)

# pdftoppm names it cover_front_ebook-1.jpg — rename
os.rename("/home/claude/techbook/kdp/cover_front_ebook-1.jpg", JPG_OUT)
print(f"JPEG written: {JPG_OUT}")

# Verify
from PIL import Image
im = Image.open(JPG_OUT)
print(f"Front eBook cover: {im.size[0]} x {im.size[1]} px")

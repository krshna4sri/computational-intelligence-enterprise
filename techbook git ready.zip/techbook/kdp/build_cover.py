"""
KDP cover wrap generator for "Computational Intelligence for Enterprise Systems".

Produces a print-ready PDF sized for Amazon KDP paperback:
    Trim  : 6.000" × 9.000"
    Bleed : 0.125" on each outer edge
    Spine : calculated from interior page count (0.002252" per page, white paper)
    Pages : 99 -> spine width = 0.223" (no spine text per author preference)

Total cover wrap:
    Width  = 6 + 0.125 + 0.223 + 6 + 0.125 = 12.473"
    Height = 9 + 0.125 + 0.125 = 9.250"

Safe zones (no text within these margins):
    Outer edges : 0.250" in from each bleed edge
    Spine edges : 0.0625" in from each spine edge (we use 0.125" for safety)
"""

from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white, Color
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import os

# ---------------------------------------------------------------------------
# Dimensions (in points; 1 inch = 72 pt)
# ---------------------------------------------------------------------------

TRIM_W     = 6.000 * inch
TRIM_H     = 9.000 * inch
BLEED      = 0.125 * inch
SPINE_W    = 0.295 * inch               # 131 pages × 0.002252" = 0.2815"
SAFE_EDGE  = 0.250 * inch
SAFE_SPINE = 0.125 * inch

TOTAL_W = (BLEED + TRIM_W + SPINE_W + TRIM_W + BLEED)   # 12.473"
TOTAL_H = (BLEED + TRIM_H + BLEED)                       # 9.250"

# X coordinates of the key boundaries (reportlab origin is bottom-left)
X_BACK_BLEED_L   = 0
X_BACK_TRIM_L    = BLEED
X_BACK_TRIM_R    = BLEED + TRIM_W
X_SPINE_L        = X_BACK_TRIM_R
X_SPINE_R        = X_SPINE_L + SPINE_W
X_FRONT_TRIM_L   = X_SPINE_R
X_FRONT_TRIM_R   = X_FRONT_TRIM_L + TRIM_W
X_FRONT_BLEED_R  = TOTAL_W

Y_BOTTOM_BLEED = 0
Y_BOTTOM_TRIM  = BLEED
Y_TOP_TRIM     = BLEED + TRIM_H
Y_TOP_BLEED    = TOTAL_H

# ---------------------------------------------------------------------------
# Color palette (matches the interior)
# ---------------------------------------------------------------------------

ACCENT      = HexColor("#1F4E79")
ACCENT_SOFT = HexColor("#2E5C8A")
SUBTLE      = HexColor("#595959")
LIGHT       = HexColor("#7FA7D9")
CREAM       = HexColor("#FAFBFE")
BG          = HexColor("#F6F7FA")      # back/front main background
INK         = HexColor("#1F2328")


def draw_cover(out_path: str) -> None:
    c = canvas.Canvas(out_path, pagesize=(TOTAL_W, TOTAL_H))

    # ------ Full-page background (everything prints to the bleed edge) ----
    c.setFillColor(BG)
    c.rect(0, 0, TOTAL_W, TOTAL_H, stroke=0, fill=1)

    # ------ Spine -----------------------------------------------------------
    c.setFillColor(ACCENT)
    c.rect(X_SPINE_L, 0, SPINE_W, TOTAL_H, stroke=0, fill=1)

    # =========================================================================
    # FRONT COVER (right half)
    # =========================================================================
    # Top accent band (extends to top bleed)
    TOP_BAND_H = 0.75 * inch
    c.setFillColor(ACCENT)
    c.rect(X_FRONT_TRIM_L, Y_TOP_TRIM - TOP_BAND_H + BLEED,
           TRIM_W + BLEED, TOP_BAND_H + BLEED, stroke=0, fill=1)

    # Thin secondary band just below
    c.setFillColor(LIGHT)
    c.rect(X_FRONT_TRIM_L, Y_TOP_TRIM - TOP_BAND_H - 0.05 * inch + BLEED,
           TRIM_W + BLEED, 0.04 * inch, stroke=0, fill=1)

    # Title
    front_center_x = X_FRONT_TRIM_L + TRIM_W / 2
    title_y = Y_TOP_TRIM - 2.1 * inch
    c.setFillColor(ACCENT)
    c.setFont("Helvetica-Bold", 40)
    c.drawCentredString(front_center_x, title_y, "Computational")
    c.drawCentredString(front_center_x, title_y - 0.55 * inch, "Intelligence")
    c.setFont("Helvetica-Bold", 26)
    c.drawCentredString(front_center_x, title_y - 1.20 * inch, "for Enterprise Systems")

    # Subtitle
    c.setFont("Helvetica-Oblique", 14)
    c.setFillColor(SUBTLE)
    c.drawCentredString(front_center_x, title_y - 1.85 * inch, "Advanced Optimization Algorithms")
    c.drawCentredString(front_center_x, title_y - 2.10 * inch, "with Working Prototypes")

    # Decorative rule
    c.setStrokeColor(LIGHT)
    c.setLineWidth(1.2)
    c.line(X_FRONT_TRIM_L + 1.2 * inch, title_y - 2.45 * inch,
           X_FRONT_TRIM_R - 1.2 * inch, title_y - 2.45 * inch)

    # Algorithm chips
    c.setFont("Helvetica", 9)
    c.setFillColor(SUBTLE)
    chips_y = title_y - 2.80 * inch
    c.drawCentredString(front_center_x, chips_y,
                        "AGOA  ◆  SIMULATED ANNEALING  ◆  PSO")
    c.drawCentredString(front_center_x, chips_y - 0.20 * inch,
                        "HYBRID PSO-GA  ◆  BESSEL-FOURIER DESCRIPTORS")

    # "A TECHNICAL MANUAL" small caps near bottom
    tag_y = Y_BOTTOM_TRIM + 1.80 * inch
    c.setFont("Helvetica-Bold", 10)
    c.setFillColor(LIGHT)
    c.drawCentredString(front_center_x, tag_y, "A  T E C H N I C A L   M A N U A L")

    # Author block
    c.setFont("Helvetica-Bold", 18)
    c.setFillColor(ACCENT)
    c.drawCentredString(front_center_x, Y_BOTTOM_TRIM + 1.20 * inch,
                        "Ravi Chandra Srikanth Cherukupalli")
    c.setFont("Helvetica-Oblique", 10)
    c.setFillColor(SUBTLE)
    c.drawCentredString(front_center_x, Y_BOTTOM_TRIM + 0.95 * inch,
                        "SAP Chief Architect  •  SmartApp Inc.")

    # Bottom accent band
    BOT_BAND_H = 0.35 * inch
    c.setFillColor(ACCENT)
    c.rect(X_FRONT_TRIM_L, 0, TRIM_W + BLEED, BOT_BAND_H + BLEED, stroke=0, fill=1)

    # =========================================================================
    # BACK COVER (left half)
    # =========================================================================
    back_center_x = X_BACK_TRIM_L + TRIM_W / 2
    back_left_x   = X_BACK_TRIM_L + SAFE_EDGE
    back_right_x  = X_BACK_TRIM_R - SAFE_EDGE
    back_text_w   = back_right_x - back_left_x

    # Top accent band (matches front)
    c.setFillColor(ACCENT)
    c.rect(0, Y_TOP_TRIM - TOP_BAND_H + BLEED,
           X_BACK_TRIM_R - X_BACK_BLEED_L, TOP_BAND_H + BLEED, stroke=0, fill=1)
    c.setFillColor(LIGHT)
    c.rect(0, Y_TOP_TRIM - TOP_BAND_H - 0.05 * inch + BLEED,
           X_BACK_TRIM_R - X_BACK_BLEED_L, 0.04 * inch, stroke=0, fill=1)

    # Top-banner headline
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(back_center_x, Y_TOP_TRIM - 0.52 * inch,
                        "When the textbook solvers break down.")

    # Synopsis paragraphs
    def draw_wrapped(x, y, width, text, font_name, size, color, leading=None):
        """Simple word-wrap draw. Returns the y coordinate below the last line."""
        if leading is None:
            leading = size * 1.30
        c.setFont(font_name, size)
        c.setFillColor(color)
        words = text.split()
        line = ""
        current_y = y
        for w in words:
            test = (line + " " + w).strip()
            if c.stringWidth(test, font_name, size) <= width:
                line = test
            else:
                c.drawString(x, current_y, line)
                current_y -= leading
                line = w
        if line:
            c.drawString(x, current_y, line)
            current_y -= leading
        return current_y

    body_y = Y_TOP_TRIM - TOP_BAND_H - 0.45 * inch

    para1 = ("Every enterprise decision is, at some level, an optimization problem. Inventory levels. "
             "Supplier routing. Transport-mode selection. Plant configuration. For decades the default "
             "tool has been mathematical programming — rigorous, elegant, and increasingly unable to "
             "handle the reality of modern supply chains.")
    body_y = draw_wrapped(back_left_x, body_y, back_text_w, para1,
                          "Helvetica", 10.5, INK, leading=13)

    body_y -= 6
    para2 = ("This book is about what you reach for instead. Five algorithms, each drawn from a real "
             "project, each explained carefully from the mathematics down to the code — an adaptive "
             "genetic algorithm, multi-objective simulated annealing, particle swarm, a hybrid PSO-GA, "
             "and Bessel-Fourier descriptors for interpretable image recognition.")
    body_y = draw_wrapped(back_left_x, body_y, back_text_w, para2,
                          "Helvetica", 10.5, INK, leading=13)

    body_y -= 6
    para3 = ("Every algorithm comes with a working Python proof-of-concept, CSV datasets, a fitness "
             "function you can adapt, and a deployment blueprint for moving from notebook to "
             "production. The code is tested end-to-end.")
    body_y = draw_wrapped(back_left_x, body_y, back_text_w, para3,
                          "Helvetica", 10.5, INK, leading=13)

    # --- "What you'll find inside" heading + bullets ---
    body_y -= 8
    c.setFont("Helvetica-Bold", 12)
    c.setFillColor(ACCENT)
    c.drawString(back_left_x, body_y, "What you'll find inside")
    body_y -= 16

    bullets = [
        "Eighteen chapters across seven parts, from foundations and stochastic",
        "mathematics to deployment blueprints and observability playbooks.",
        "Eight CSV datasets driving reproducible worked examples.",
        "Thirty-two chapter-end exercises with selected solutions.",
        "A unified Python package with a shared RunReport schema so results",
        "compare cleanly across algorithms.",
        "A four-stage production rollout pattern built from real engagements.",
    ]
    for b in bullets:
        c.setFont("Helvetica", 10)
        c.setFillColor(INK)
        c.drawString(back_left_x + 0.10 * inch, body_y, "•  " + b)
        body_y -= 13

    # --- Who this book is for ---
    body_y -= 8
    c.setFont("Helvetica-Bold", 12)
    c.setFillColor(ACCENT)
    c.drawString(back_left_x, body_y, "Who this book is for")
    body_y -= 15
    wfb = ("Supply-chain architects, data scientists, ML engineers, and technical managers "
           "who want both the mathematical grounding to reason about metaheuristic algorithms and "
           "the code to adapt them to their own problems.")
    body_y = draw_wrapped(back_left_x, body_y, back_text_w, wfb,
                          "Helvetica", 10, INK, leading=12.5)

    # --- ISBN / barcode placeholder box (bottom-right of back) ---
    bc_w, bc_h = 1.80 * inch, 0.95 * inch
    bc_x = back_right_x - bc_w
    bc_y = Y_BOTTOM_TRIM + 0.55 * inch
    c.setFillColor(white)
    c.setStrokeColor(SUBTLE)
    c.setLineWidth(0.5)
    c.rect(bc_x, bc_y, bc_w, bc_h, stroke=1, fill=1)
    c.setFont("Helvetica-Bold", 9)
    c.setFillColor(SUBTLE)
    c.drawString(bc_x + 0.10 * inch, bc_y + bc_h - 0.22 * inch, "ISBN 978-X-XXXXXX-XX-X")
    c.setFont("Helvetica", 7)
    c.drawString(bc_x + 0.10 * inch, bc_y + bc_h - 0.36 * inch, "(barcode placeholder — KDP will generate)")
    c.setFillColor(HexColor("#E6E6E6"))
    c.rect(bc_x + 0.10 * inch, bc_y + 0.10 * inch,
           bc_w - 0.20 * inch, bc_h - 0.55 * inch, stroke=0, fill=1)

    # --- Price tag / price hint in bottom-left ---
    c.setFont("Helvetica", 8)
    c.setFillColor(SUBTLE)
    c.drawString(back_left_x, Y_BOTTOM_TRIM + 0.55 * inch, "Computing / Operations Research")
    c.drawString(back_left_x, Y_BOTTOM_TRIM + 0.40 * inch, "Metaheuristic Algorithms")

    # Bottom accent band (matches front)
    c.setFillColor(ACCENT)
    c.rect(0, 0, X_BACK_TRIM_R - X_BACK_BLEED_L, BOT_BAND_H + BLEED, stroke=0, fill=1)

    # Publisher / imprint line at very bottom (inside safe zone)
    c.setFillColor(white)
    c.setFont("Helvetica-Oblique", 8)
    c.drawString(back_left_x, BLEED + 0.12 * inch,
                 "SmartApp Publishing  •  Rhode Island, USA")

    c.save()
    print(f"Cover wrap written: {out_path}")
    print(f"  Dimensions: {TOTAL_W/inch:.3f}\" × {TOTAL_H/inch:.3f}\"")
    print(f"  Spine width: {SPINE_W/inch:.3f}\" (131 interior pages at 6x9, white paper)")


if __name__ == "__main__":
    os.makedirs("/home/claude/techbook/kdp", exist_ok=True)
    draw_cover("/home/claude/techbook/kdp/cover_wrap_KDP.pdf")

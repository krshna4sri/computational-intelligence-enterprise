# Amazon KDP Publishing Metadata

This document contains every field you need to fill in when publishing the book on Amazon KDP. Each section is labeled with the KDP dashboard field it corresponds to, the character limit KDP enforces, and content written to fit that limit.

---

## 1.  Book details

| KDP field | Value |
|---|---|
| **Language** | English |
| **Book title** | Computational Intelligence for Enterprise Systems |
| **Subtitle** | Advanced Optimization Algorithms with Working Prototypes |
| **Series** | *(leave blank — this is Volume I of a planned series; only fill after Volume II is ready)* |
| **Edition number** | 1 |
| **Author (primary)** | Ravi Chandra Srikanth Cherukupalli |
| **Contributors** | *(none)* |
| **Publisher / imprint** | SmartApp Publishing *(optional free-text field on KDP)* |
| **Publication date** | *(select the date on which the book will be made live)* |
| **Copyright year** | 2026 |
| **Publishing rights** | I own the copyright and hold the necessary publishing rights |

---

## 2.  Description (book page blurb)

**KDP limit: 4,000 characters including spaces. Supports limited HTML: `<b>`, `<i>`, `<em>`, `<strong>`, `<br>`, `<p>`, `<ul>`, `<li>`, `<h4>`, `<h5>`, `<h6>`.** The description below is 1,780 characters — well under the cap, with room for localized edits.

```html
<h4>When the textbook solvers break down.</h4>

<p>Every enterprise decision is, at some level, an optimization problem. Inventory levels. Supplier routing. Transport-mode selection. Plant configuration. For decades the default tool has been mathematical programming — rigorous, elegant, and increasingly unable to handle the reality of modern supply chains: non-linear costs, combinatorial choices, conflicting objectives, and answers needed in seconds rather than hours.</p>

<p><b>This book is about what you reach for instead.</b> Five algorithms, each drawn from a real project, each explained carefully from the mathematics down to the code: an adaptive genetic algorithm for supply-network design, multi-objective simulated annealing for cost-versus-carbon transport optimization, particle swarm for multi-product inventory, a hybrid PSO-GA for the cases where neither pure method is enough, and Bessel-Fourier descriptors for interpretable image recognition.</p>

<p>Every algorithm comes with a working Python proof-of-concept, CSV datasets, a fitness function you can adapt, and a deployment blueprint for moving from notebook to production. Type one command and every algorithm runs end-to-end on your laptop, producing the exact numbers quoted in the case studies. This is a practitioner's book — theory where it clarifies, code where it compiles, and candor about when to use which method.</p>

<h4>Inside you'll find:</h4>
<ul>
<li>Eighteen chapters across seven parts — from foundations and stochastic mathematics through AGOA, Simulated Annealing, Particle Swarm, Hybrid PSO-GA, and Bessel-Fourier Descriptors, to a full deployment playbook.</li>
<li>A dedicated Mathematical Machinery part (Chapters 3–4) giving the working primer on metaheuristics and stochastic processes that anchors every algorithm.</li>
<li>Eight CSV datasets driving reproducible worked examples in Appendix D.</li>
<li>Thirty-two chapter-end exercises with selected solutions in Appendix E.</li>
<li>A reference architecture, observability playbook, and four-stage rollout pattern built from production experience.</li>
</ul>

<h4>Who this book is for</h4>
<p>Supply-chain architects, data scientists, ML engineers, and technical managers who want both the mathematical grounding to reason about metaheuristic algorithms and the code to adapt them to their own problems. A reader comfortable with first-year calculus, basic linear algebra, and intermediate Python will find every chapter approachable.</p>
```

---

## 3.  Keywords

KDP allows up to 7 keyword slots. Each slot is 50 characters max. Pick 7 from the prioritized list below — reorder based on what ranks best in your niche.

| # | Keyword phrase | Why |
|---|---|---|
| 1 | `metaheuristic optimization python`       | Core subject; searchable |
| 2 | `supply chain optimization book`          | Primary target audience |
| 3 | `genetic algorithm inventory`             | High-volume search term in ops research |
| 4 | `particle swarm optimization guide`       | Canonical algorithm name |
| 5 | `simulated annealing supply chain`        | Specific multi-objective niche |
| 6 | `operations research practitioner`        | Audience intent |
| 7 | `optimization algorithms with code`       | Differentiator vs academic titles |

Alternate candidates to rotate through if analytics show weak pull on any of the above:
`hybrid pso ga`, `bessel fourier descriptor`, `python optimization tutorial`, `multi objective pareto`, `AGOA algorithm`, `fitness function design`, `black box optimization`.

---

## 4.  Categories

KDP allows up to 3 categories per format (Kindle eBook and Paperback are separate). Recommended path:

**Paperback**
- Books › Computers & Technology › Computer Science › AI & Machine Learning
- Books › Business & Money › Management & Leadership › Production & Operations
- Books › Science & Math › Mathematics › Applied › Operations Research

**Kindle eBook**
- Kindle Store › Kindle eBooks › Computers & Technology › AI & Machine Learning › Expert Systems
- Kindle Store › Kindle eBooks › Business & Money › Industries › Management Science
- Kindle Store › Kindle eBooks › Engineering & Transportation › Engineering › Industrial, Manufacturing & Operational Systems

---

## 5.  Age range and grade range

Not applicable (adult professional non-fiction). Leave blank.

---

## 6.  Interior formatting notes

When uploading the interior PDF/DOCX:

- **Trim size:** 6.0″ × 9.0″ (Bookstore standard)
- **Interior:** Black & white, white paper
- **Bleed setting:** No bleed (text pages only; no images reach page edges)
- **Page count:** 131 pages *(produced by the 6×9 KDP interior; KDP automatically computes spine width from this)*
- **Margins:** 0.75″ inside (gutter), 0.5″ outside, 0.75″ top and bottom; mirror margins enabled
- **ISBN:** Use the free KDP ISBN or bring your own. If you use the free ISBN, imprint must be "Independently published"; if you bring your own, the imprint "SmartApp Publishing" on the cover matches.
- **Large Print:** No
- **Low-content / No-content:** No

---

## 7.  Cover upload

Use the generated file **`cover_wrap_KDP.pdf`**.

| Field | Value |
|---|---|
| Cover finish | Matte (recommended for tech books — less fingerprint-prone than glossy) |
| Bleed | Yes — the PDF is already set up with 0.125″ bleed |
| Spine text | None (blank spine by design) |
| Cover dimensions (computed) | 12.545″ × 9.250″ total (spine 0.295″ for 131-page white-paper interior) |

---

## 8.  Pricing

Two pricing strategies to consider:

**Strategy A — broad-reach (recommended for first edition)**
- Kindle eBook: **$9.99** (70% royalty tier; lands on KU if enrolled)
- Paperback: **$24.99** (KDP minimum for 99-page B&W paperback at 6×9 is around $3.98; $24.99 gives healthy royalty)

**Strategy B — premium/specialist**
- Kindle eBook: **$19.99**
- Paperback: **$39.99**

Strategy A is suggested because the field is crowded and discoverability matters more than per-unit margin for a first release. Consider moving to B once reviews are established.

---

## 9.  Royalty and distribution

- **Royalty option (Kindle):** 70% (book is priced ≥ $2.99 and ≤ $9.99, passes threshold)
- **KDP Select enrollment:** Optional. Trade-off is 90-day exclusivity for higher royalty on KU page-reads. For a technical reference, KU readers skew toward fiction — enrollment is often NOT worth the exclusivity lock-in.
- **Paperback distribution:** Amazon + Expanded Distribution (enables libraries, independent bookstores)

---

## 10.  Author Central bio

**KDP limit: 2,000 characters.** Below is 1,020 characters.

```
Ravi Chandra Srikanth Cherukupalli is Chief Architect at SmartApp Inc., where he leads enterprise supply-chain and data-platform engagements for Fortune 500 clients. His work combines classical operations research with modern computational methods and has produced a series of research preprints — on Adaptive Genetic Optimization (AGOA), multi-objective Simulated Annealing for supply-chain problems, Particle Swarm Optimization for inventory management, hybrid PSO-GA algorithms, and Bessel-Fourier Descriptors for image recognition — which together form the basis of this book.

Ravi has deep experience in SAP supply-chain architecture and has deployed production optimization systems across retail, manufacturing, healthcare, and logistics sectors. He is based in Rhode Island, USA.

Computational Intelligence for Enterprise Systems is his first book-length consolidation of applied metaheuristics for practitioners.
```

---

## 11.  Back-matter checklist (inside the book, for KDP compliance)

- [x] Title page with book title, subtitle, author
- [x] Copyright page (add ISBN after it is assigned)
- [x] Table of contents
- [x] Body chapters
- [x] Appendices
- [ ] *(Optional)* Acknowledgments page — add if desired
- [ ] *(Optional)* "Also by the author" page — add if Volume II is published
- [ ] *(Recommended)* Review request page — "If you found this book useful, please leave a review on Amazon"

---

## 12.  Pre-launch QA checklist

- [ ] Run `python -m poc.run_all_demos` one more time on a clean machine and confirm output matches the book's case studies
- [ ] Open the DOCX / PDF in Kindle Create and skim every chapter for reflow issues
- [ ] Open the cover PDF in Adobe Reader or Preview; confirm no text falls into the spine safe zone
- [ ] Verify all hyperlinks work (KDP strips some but retains internal TOC links)
- [ ] Confirm the blurb renders correctly in KDP's live preview (they strip unsupported HTML silently)
- [ ] Order a physical proof copy before going live — screen view cannot catch every cover or margin issue

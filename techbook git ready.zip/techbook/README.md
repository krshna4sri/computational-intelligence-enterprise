# Computational Intelligence for Enterprise Systems — Working POCs

Companion source code for the tech book *Computational Intelligence for Enterprise Systems: Advanced Optimization Algorithms with Working Prototypes* by Ravi Chandra Srikanth Cherukupalli.

Every algorithm discussed in the book is implemented here as a small, standalone Python module. All datasets are synthetic and generated deterministically from seeds, so every number printed in the book can be reproduced exactly by running the code.

---

## Prerequisites

- Python 3.10 or newer
- Five scientific-Python packages

```bash
pip install numpy scipy scikit-learn matplotlib pandas
```

---

## Directory layout

```
techbook/
├── poc/
│   ├── common/                    # Shared RunReport, dataset generators, CSV loaders
│   │   ├── utils.py
│   │   └── loaders.py
│   ├── datasets/                  # CSV datasets driving Appendix D worked examples
│   │   ├── inventory_sample.csv
│   │   ├── suppliers.csv
│   │   ├── plants.csv
│   │   ├── distribution_centers.csv
│   │   ├── sp_cost_matrix.csv
│   │   ├── pd_cost_matrix.csv
│   │   ├── transport_lanes.csv
│   │   ├── transport_modes.csv                      # electric-rail (rail dominates)
│   │   ├── transport_modes_diesel_rail.csv          # diesel-rail (real Pareto trade-off)
│   │   └── bfd_features_sample.csv
│   ├── agoa/                      # Chapter 3–5: Adaptive Genetic Optimization
│   │   └── agoa_scm.py
│   ├── simulated_annealing/       # Chapter 6–7: Multi-Objective Simulated Annealing
│   │   └── mosa_scm.py
│   ├── pso/                       # Chapter 8–9: Particle Swarm Optimization
│   │   └── pso_inventory.py
│   ├── hybrid_pso_ga/             # Chapter 10–11: Hybrid PSO-GA
│   │   └── hybrid.py
│   ├── bessel_bfd/                # Chapter 12–13: Bessel-Fourier Descriptors
│   │   └── bfd_classifier.py
│   ├── run_all_demos.py           # Unified runner with synthetic data
│   └── worked_examples.py         # Appendix D runner — uses CSV datasets
└── README.md                      # This file
```

All directories are Python packages. Run everything from the repository root with `python -m` so imports resolve correctly.

---

## Quickstart — run everything

```bash
cd techbook
python -m poc.run_all_demos            # All algorithms on synthetic seeded data
python -m poc.worked_examples          # All algorithms on CSV datasets (Appendix D)
```

Expected output (wall times vary by machine):

```
==============================================================================
 COMPARATIVE RESULTS
==============================================================================
Algorithm        Problem                      Fitness         Iters     Time
----------------------------------------------------------------------------
AGOA             three_tier_supply_network    9,570,011.12      120    0.31s
SA (weighted)    multi_obj_transport          503,951.13        500    0.01s
MOSA archive     multi_obj_transport          923,910.41        500    0.01s
PSO              inventory_management         2,769.79          200    0.09s
Hybrid PSO-GA    inventory_management         2,769.79          200    0.41s
BFD+SVM          shape_classification         acc=0.800           1    0.10s
```

---

## Run one algorithm at a time

| Algorithm        | Book chapters | Command                                          |
| ---------------- | ------------- | ------------------------------------------------ |
| AGOA             | 3 – 5         | `python -m poc.agoa.agoa_scm`                    |
| Simulated Annealing (weighted + archive + sweep) | 6 – 7 | `python -m poc.simulated_annealing.mosa_scm` |
| PSO              | 8 – 9         | `python -m poc.pso.pso_inventory`                |
| Hybrid PSO-GA    | 10 – 11       | `python -m poc.hybrid_pso_ga.hybrid`             |
| BFD + SVM        | 12 – 13       | `python -m poc.bessel_bfd.bfd_classifier`        |

Each produces a `RunReport` (see `poc/common/utils.py`) with a common schema:

```python
@dataclass
class RunReport:
    algorithm:          str
    problem:            str
    best_fitness:       float
    best_solution:      Any
    iterations:         int
    wall_time_seconds:  float
    convergence_trace:  list[float]
    extra:              dict[str, Any]
```

Saving a run to JSON is one call: `report.to_json("my_run.json")`.

---

## Using the modules from your own code

```python
from poc.common import make_inventory_dataset, set_seed
from poc.pso.pso_inventory import InventoryProblem, PSOConfig, run_pso
from poc.hybrid_pso_ga.hybrid  import HybridConfig, run_hybrid_pso_ga

set_seed(42)
data    = make_inventory_dataset(n_products=8, seed=42)
problem = InventoryProblem(data=data)

pso_report    = run_pso(problem, PSOConfig(n_particles=30, iterations=250))
hybrid_report = run_hybrid_pso_ga(problem, HybridConfig(n_particles=30, iterations=250))

print(pso_report.summary())
print(hybrid_report.summary())
```

Swap `make_inventory_dataset` for your own loader that returns the same dict structure, and the algorithms need no changes.

---

## Replacing synthetic data with real data

Every dataset generator returns a plain `dict` of NumPy arrays. A production deployment replaces the generator with a loader that returns the same structure.

### Inventory

```python
import pandas as pd, numpy as np

def load_inventory_from_erp(csv_path: str) -> dict:
    df = pd.read_csv(csv_path)
    return {
        "product_id":        df["product_id"].to_numpy(),
        "historical_demand": df["demand"].to_numpy(float),
        "holding_cost":      df["holding_cost"].to_numpy(float),
        "ordering_cost":     df["ordering_cost"].to_numpy(float),
        "shortage_cost":     df["shortage_cost"].to_numpy(float),
        "lead_time":         df["lead_time"].to_numpy(float),
    }
```

### Supply network (AGOA)

Replace `make_supply_network` with a function returning the same seven keys (`n_suppliers`, `n_plants`, `n_dcs`, `supplier_capacity`, `plant_capacity`, `dc_demand`, `sp_cost`, `pd_cost`, `fixed_plant_cost`) populated from your ERP.

### Transportation (SA)

Replace `make_transportation_network` with a loader returning `distance_km`, `demand_units`, `mode_cost_per_km_per_unit`, `mode_emissions_per_km_per_unit`, `mode_speed_kmh`, `mode_names`.

See **Chapter 15 — Deployment Blueprint** in the book for the full production reference architecture.

---

## Reproducibility

Every stochastic step flows through a seeded `numpy.random.Generator`. Two runs with identical `seed` and `config` produce bit-identical outputs. If you modify the code and want to preserve reproducibility, route any new random draws through the `rng` argument, not `random.random()` or `np.random.*` globals.

---

## License & attribution

Code released for educational and research use. If you fork or extend this work, please cite the original preprints listed in **Appendix C** of the book.

Author: **Ravi Chandra Srikanth Cherukupalli** — SAP Chief Architect, SmartApp Inc., RI, USA.
